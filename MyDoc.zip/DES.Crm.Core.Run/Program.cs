﻿using DES.Crm.Core.Common.Security;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Linq;
using System.Diagnostics;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Tooling.Connector;
using Microsoft.Crm.Sdk.Messages;
using System.Configuration;
using System.Net;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Metadata;
using Excel = Microsoft.Office.Interop.Excel;
using System.Runtime.InteropServices;

namespace DES.Crm.Core.Run
{
    class Program
    {
        private static DefaultLogger _defaultLogger = new DefaultLogger();
        private static Dictionary<Guid, Position> userPositionDictionary = new Dictionary<Guid, Position>();
        private static List<UserPositionLog> _lstMigrationLog = new List<UserPositionLog>();
        private static System.Configuration.AppSettingsReader settingsReader = new AppSettingsReader();
        private static string exportToExcel = (string)settingsReader.GetValue("ExportToExcel", typeof(String));
        private static string exportPath = (string)settingsReader.GetValue("ExportPath", typeof(String));


        // args can contain crmconnectionId(as in config file e.g DEV) and the location of the config file
        //if location of config file is to be specified in args then use syntax config-"pathof the config file"
        //if crmconnectionid is also reqd to be passed along with config file location to args, prefix ccrmconnection id with conn-
        //in case there is no config file location passed, by default it picks the config.xml from the output directory
        //when there is no config file connectionid can be passed either by using the prefix conn- or directly the ids e.g DEV
        //if no connections is passed as parameter then it will pick all the connections in the config file with execute=true
        static void Main(string[] args)
        {
            _defaultLogger.Info("STARTS EXECUTION");

            string xmlDocpath = string.Empty;
            bool useNamedConnections = false;
            List<string> conns = new List<string>();

            if (args.Length > 0)
            {
                for (int counter = 0; counter < args.Length; counter++)
                {
                    if (args[counter].Contains("config-"))
                    {
                        xmlDocpath = args[counter].Split('-')[1].Trim();
                        useNamedConnections = true;
                    }
                    else if (args[counter].Contains("conn-"))
                        conns.Add(args[counter].Split('-')[1].Trim());
                }
            }

            if (string.IsNullOrEmpty(xmlDocpath))
                // Reads Config.xml, connects to the specified crmconnection and executes all the Run nodes
                xmlDocpath = "Config.xml";
            XDocument xDoc = XDocument.Load(xmlDocpath);
            _defaultLogger.Info("Loaded config file: " + xmlDocpath);

            /***logic to manipulate the args[] to contain only the crmconnectionid and remove config file path from args if it exists***/
            if (conns.Count > 0)
                args = conns.ToArray();//in case of using cofig file from a different location and if we want to pass connections also as arguments make sure to use named connections in format conn-connectionId

            //no config and no connection sent as parameters indicates --> args.length==0
            //or no connection but parametrised config file which means args contains data
            else if (args.Length == 0 || useNamedConnections)
            {
                //if no connections passed fetch all crm connections from the config file
                var ConnNode = xDoc.Element("Config")
                              .Element("crmconnections")
                              .Elements()
                              .Where(x => x.Attribute("execute").Value.ToLower() == "true");
                if (ConnNode != null && ConnNode.Count() > 0)
                {
                    foreach (var connString in ConnNode)
                    {
                        conns.Add(connString.Attribute("id").Value);
                        _defaultLogger.Info("Loads connection: " + connString.Attribute("id").Value.ToString());
                    }
                }
                args = conns.ToArray();
            }
            //next case only unnmaed connections && no config--->so all values in args are already connectionids
            //No Implementation reqd  as args already contains only connectionid without prefix name conn-
            /** end logic to manipulate the args contents**/
            try
            {

                //Different instances of Des.Crm.Core.run may be running on the same server
                //if (Process.GetProcessesByName(Process.GetCurrentProcess().ProcessName).Length > 1)
                //{
                //    _defaultLogger.Info("Application DES.Crm.Core.Run.exe already running. Only one instance of this application is allowed.");
                //    return;
                //}

                var runNodes = from nodeSet in xDoc.Element("Config").Element("Run").Elements()
                               where nodeSet.Element("execute").Value.ToLower() == "true"
                               select nodeSet;
                for (int argCount = 0; argCount < args.Length; argCount++)
                {

                    List<RolesAssign> _lstUsrRoles = new List<RolesAssign>();
                    List<RolesAssign> _lstTeamRoles = new List<RolesAssign>();


                    List<UserPositionMapping> _lstInputData = new List<UserPositionMapping>();

                    foreach (var node in runNodes)
                    {
                        try

                        {
                            _defaultLogger.Info("Starts execution of node: " + node.Name.LocalName.ToString());
                            switch (node.Name.LocalName)
                            {
                                case "SendPendingEmailsViaSMTP":
                                    CreateSendPendingEmailsViaSMTP(args[argCount], xDoc, node);
                                    break;
                                case "LaunchWorkflowOnFetch":
                                    string fetch = Convert.ToString(node.Descendants("Fetch").FirstOrDefault().Value);
                                    string WorkflowId = Convert.ToString(node.Descendants("WorkflowID").FirstOrDefault().Value);
                                    ExecuteWorkflowOnFetch(args[argCount], WorkflowId, fetch, xDoc);
                                    break;
                                case "AssignSecurityRoleToUser":
                                    RolesAssign _usrRoleMap = new RolesAssign();
                                    _usrRoleMap.Flag = Convert.ToString(node.Descendants("Action").FirstOrDefault().Value);
                                    _usrRoleMap.Name = Convert.ToString(node.Descendants("UserName").FirstOrDefault().Value);
                                    _usrRoleMap.RoleName = Convert.ToString(node.Descendants("RoleName").FirstOrDefault().Value);
                                    _lstUsrRoles.Add(_usrRoleMap);
                                    break;
                                case "AssignSecurityRoleToTeam":
                                    RolesAssign _teamRoleMap = new RolesAssign();
                                    _teamRoleMap.Flag = Convert.ToString(node.Descendants("Action").FirstOrDefault().Value);
                                    _teamRoleMap.Name = Convert.ToString(node.Descendants("TeamName").FirstOrDefault().Value);
                                    _teamRoleMap.RoleName = Convert.ToString(node.Descendants("RoleName").FirstOrDefault().Value);
                                    _lstTeamRoles.Add(_teamRoleMap);
                                    break;
                                case "RestartAsyncOperationRecordsOnFetch":
                                    string AsynOpnfetch = Convert.ToString(node.Descendants("Fetch").FirstOrDefault().Value);
                                    RestartAsyncOperationsOnFetch(args[argCount], xDoc, AsynOpnfetch);
                                    break;
                                case "AssignPositionToUser":
                                    UserPositionMapping _usrPositionMap = new UserPositionMapping();
                                    _usrPositionMap.Action = Convert.ToString(node.Descendants("Action").FirstOrDefault().Value).Trim().ToLower();
                                    _usrPositionMap.UserName = Convert.ToString(node.Descendants("UserName").FirstOrDefault().Value).Trim().ToLower();
                                    _usrPositionMap.PositionName = Convert.ToString(node.Descendants("PositionName").FirstOrDefault().Value).Trim().ToLower();
                                    _usrPositionMap.IsMainPosition = true;
                                    _lstInputData.Add(_usrPositionMap);
                                    break;
                                case "AssignOtherPositionToUser":
                                    UserPositionMapping _usrOtherPositionMap = new UserPositionMapping();
                                    _usrOtherPositionMap.Action = Convert.ToString(node.Descendants("Action").FirstOrDefault().Value).Trim().ToLower();
                                    _usrOtherPositionMap.UserName = Convert.ToString(node.Descendants("UserName").FirstOrDefault().Value).Trim().ToLower();
                                    _usrOtherPositionMap.PositionName = Convert.ToString(node.Descendants("PositionName").FirstOrDefault().Value).Trim().ToLower();
                                    _usrOtherPositionMap.IsMainPosition = false;
                                    _lstInputData.Add(_usrOtherPositionMap);
                                    break;
                                case "DeleteRecordsOnFetch":
                                    string fetchX = Convert.ToString(node.Descendants("Fetch").FirstOrDefault().Value);
                                    DeleteRecordsOnFetch(args[argCount], xDoc, fetchX);
                                    break;

                                case "BulkUpdateRelationShip":
                                    var entityName = Convert.ToString(node.Descendants("EntityName").FirstOrDefault().Value).Trim().ToLower();
                                    bool updateAllRelationShips = Convert.ToString(node.Descendants("EntityName").FirstOrDefault().Value.Trim().ToLower()) == "true" ? true : false;
                                    var relationShipName = Convert.ToString(node.Descendants("RelationshipName").FirstOrDefault().Value).Trim().ToLower();
                                    var privilegeName = Convert.ToString(node.Descendants("Privilege").FirstOrDefault().Value).Trim().ToLower();
                                    var cascadeConfiguration = Convert.ToString(node.Descendants("CascadeConfiguration").FirstOrDefault().Value).Trim().ToLower();
                                    UpdateRelationShip(args[argCount], xDoc, entityName, updateAllRelationShips, relationShipName, privilegeName, cascadeConfiguration);
                                    break;
                                case "RootBusinessUnitRename":
                                    var newBUName = Convert.ToString(node.Descendants("NewName").FirstOrDefault().Value).Trim();
                                    RootBusinessUnitRename(args[argCount], xDoc, newBUName);
                                    break;
                                case "BusinessUnitSetIIQEnabled":
                                    var businessUnitName = Convert.ToString(node.Descendants("BusinessUnitName").FirstOrDefault().Value).Trim();
                                    var iiqEnabledFieldName = Convert.ToString(node.Descendants("IIQEnabledFieldName").FirstOrDefault().Value).Trim().ToLower();
                                    var iiqEnabled = Convert.ToBoolean(node.Descendants("IIQEnabled").FirstOrDefault().Value.Trim());
                                    BusinessUnitSetIIQEnabled(args[argCount], xDoc, businessUnitName, iiqEnabledFieldName, iiqEnabled);
                                    break;
                                case "RemovePositionWhenUserDisabled":
                                    string fetchXml = Convert.ToString(node.Descendants("Fetch").FirstOrDefault().Value);
                                    _defaultLogger.Info("Starting RemovePositionWhenUserDisabled");
                                    RemovePositionsOnFetch(args[argCount], fetchXml, xDoc);
                                    break;
                                case "UpdateDataRetentionRecordsAfterPolicyChange":
                                    string fetchXmlForMOdifications = Convert.ToString(node.Descendants("Fetch").FirstOrDefault().Value);
                                    _defaultLogger.Info("Starting UpdateDataRetentionRecordsAfterPolicyChange");
                                    UpdateDataRetentionRecordsAfterPolicyChange(args[argCount], fetchXmlForMOdifications, xDoc);
                                    break;
                                case "RetrieveJavaScriptEventHandlers":
                                    var entityLogicalName = Convert.ToString(node.Descendants("EntityLogicalName").FirstOrDefault().Value).Trim();
                                    RetrieveJavaScriptEventHandlers(args[argCount], xDoc, entityLogicalName);
                                    break;
                                default:
                                    _defaultLogger.Info(string.Format("No implementation found for node {0}.", node.Name.LocalName));
                                    break;
                            }
                            _defaultLogger.Info("Ends execution of node: " + node.Name.LocalName.ToString());
                        }
                        catch (Exception ex)
                        {
                            _defaultLogger.Error(ex);

                        }
                    }
                    if (_lstUsrRoles.Count > 0)
                    {
                        FetchAndAssignUserRoleMaping(_lstUsrRoles, args[argCount], xDoc);
                    }
                    if (_lstTeamRoles.Count > 0)
                        FetchAndAssignTeamRole(args[argCount], _lstTeamRoles, xDoc);
                    if (_lstInputData.Count() > 0)
                        MigratePositions(args[argCount], _lstInputData, xDoc);
                }
            }
            catch (Exception ex)
            {
                _defaultLogger.Error(ex);
            }
            finally
            {
                //update the current date time as last runtime
                SaveXmlDocument(xDoc, xmlDocpath);
                _defaultLogger.Info("ENDS EXECUTION");
                _defaultLogger.Info("");
            }

        }
        private static void UpdateRelationShip(string args, XDocument document, string entityName, bool updateAllRelationShips, string relationShipName, string privilegeName, string cascadeConfiguration)
        {

            var getNode = document.Element("Config")
                            .Element("crmconnections")
                            .Elements()
                            .Where(x => x.Attribute("id").Value.ToLower() == args.ToLower())
                            .FirstOrDefault();
            var connectionString = string.Format("RequireNewInstance={0};Url={1};Username={2};Password={3};authtype={4}",
              getNode.Attribute("requirenewinstance").Value,
              getNode.Attribute("organizationurl").Value,
              getNode.Attribute("crmuserid").Value,
              DataProtect.DecryptString(getNode.Attribute("crmuserpassword").Value),
              getNode.Attribute("authtype").Value);

            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
            var service = new Microsoft.Xrm.Tooling.Connector.CrmServiceClient(connectionString);

            if (!service.IsReady)
            {
                _defaultLogger.Error("Could not connect to CRM. " + getNode + " " + service.LastCrmException);
            }
            else
            {
                Entity entTobepdated = new Entity(entityName);
                List<OneToManyRelationshipMetadata> OneToNRelationships;

                if (updateAllRelationShips == true && relationShipName == null)
                {
                    OneToNRelationships = GetAllRelationships(entTobepdated, service);
                }

                else if (updateAllRelationShips == false && relationShipName != null)
                {
                    OneToNRelationships = VerifyIfRelationShipExists(entityName, relationShipName, service);

                    if (OneToNRelationships.Count == 1)
                    {
                        UpdateRelationShipBehaviour(privilegeName, cascadeConfiguration, service, entTobepdated, OneToNRelationships);

                    }
                    else { _defaultLogger.Info("either relationship " + relationShipName + " does not exist or already has Cascade All delete configuration or is not customizable"); }
                }
                else if (updateAllRelationShips == false && relationShipName == null)
                {
                    _defaultLogger.Info("updateAllRelationShips == false && relationShipName == null both conditions false");
                }
                else { _defaultLogger.Info("updateAllRelationShips == true && relationShipName != null both conditions true"); }

            }
        }
        private static List<OneToManyRelationshipMetadata> VerifyIfRelationShipExists(string entityName, string relationShipName, CrmServiceClient service)
        {
            RetrieveEntityRequest retrieveAllRelationshipsRequest = new RetrieveEntityRequest
            {

                EntityFilters = EntityFilters.Relationships,

                LogicalName = entityName,

                RetrieveAsIfPublished = false

            };

            RetrieveEntityResponse retrieveAllRelationshipsResponse = (RetrieveEntityResponse)service.Execute(retrieveAllRelationshipsRequest);

            var oneToNRelationships = retrieveAllRelationshipsResponse.EntityMetadata.OneToManyRelationships;

            var customRelationShips = oneToNRelationships.Where(x => x.SchemaName == relationShipName && x.IsCustomizable.Value == true && x.CascadeConfiguration.Delete != CascadeType.Cascade).ToList();

            return customRelationShips;
        }
        private static void UpdateRelationShipBehaviour(string privilegeName, string cascadeConfiguration, CrmServiceClient service, Entity entTobepdated, List<OneToManyRelationshipMetadata> OneToNRelationships)
        {
            UpdateRelationshipRequest updateRelationRequest = new UpdateRelationshipRequest();

            foreach (var relationShip in OneToNRelationships)
            {
                switch (privilegeName)
                {
                    case "delete":
                        switch (cascadeConfiguration)
                        {
                            case "cascade all":
                                relationShip.CascadeConfiguration.Delete = CascadeType.Cascade;
                                updateRelationRequest.Relationship = relationShip;
                                service.Execute(updateRelationRequest);
                                _defaultLogger.Info(string.Format("Updated Delete Cascade Configuration for {0}.", entTobepdated.LogicalName));

                                break;
                            case "remove link":
                                relationShip.CascadeConfiguration.Delete = CascadeType.RemoveLink;
                                updateRelationRequest.Relationship = relationShip;
                                service.Execute(updateRelationRequest);
                                _defaultLogger.Info(string.Format("Updated Delete Cascade Configuration for {0}.", entTobepdated.LogicalName));

                                break;
                            case "restrict":
                                relationShip.CascadeConfiguration.Delete = CascadeType.Restrict;
                                updateRelationRequest.Relationship = relationShip;
                                service.Execute(updateRelationRequest);
                                _defaultLogger.Info(string.Format("Updated Delete Cascade Configuration for {0}.", entTobepdated.LogicalName));

                                break;
                            default:
                                _defaultLogger.Info("No such configuration for Delete.");
                                _defaultLogger.Info("No such configuration for Delete.");
                                break;

                        }

                        break;

                    default:
                        _defaultLogger.Info(string.Format("No such privilege found for {0}.", entTobepdated.LogicalName));
                        _defaultLogger.Info(string.Format("No such privilege found for {0}.", entTobepdated.LogicalName));
                        break;
                }


            }
        }
        private static void ExecuteWorkflowOnFetch(string args, string workflowId, string fetchXml, XDocument document)
        {
           
            var getNode = document.Element("Config")
                           .Element("crmconnections")
                           .Elements()
                         .Where(x => x.Attribute("id").Value.ToLower() == args.ToLower())
                           .FirstOrDefault();
            var connectionString = string.Format("RequireNewInstance={0};Url={1};Username={2};Password={3};authtype={4}",
              getNode.Attribute("requirenewinstance").Value,
              getNode.Attribute("organizationurl").Value,
              getNode.Attribute("crmuserid").Value,
              DataProtect.DecryptString(getNode.Attribute("crmuserpassword").Value),
              getNode.Attribute("authtype").Value);

            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
            CrmServiceClient service = new Microsoft.Xrm.Tooling.Connector.CrmServiceClient(connectionString);

            if (!service.IsReady)
            {
                _defaultLogger.Error("Could not connect to CRM. " + getNode + " " + service.LastCrmException);
            }
            else
            {
                fetchXml = ReplaceGlobalVariables(fetchXml, document);

                EntityCollection recordsToProcess = new EntityCollection(RetrieveAllRecords(service, fetchXml));              

                if (recordsToProcess != null && recordsToProcess.Entities != null && recordsToProcess.Entities.Count > 0)
                {
                    try
                    {
                        _defaultLogger.Info("Total number of Workflows to be triggered " + recordsToProcess.Entities.Count);

                        foreach (var item in recordsToProcess.Entities)
                        {
                            try
                            {

                                ExecuteWorkflowRequest request = new ExecuteWorkflowRequest
                                {
                                    EntityId = item.Id,
                                    WorkflowId = new Guid(workflowId)
                                };
                                ExecuteWorkflowResponse response = (ExecuteWorkflowResponse)service.Execute(request); //run the workflow

                                _defaultLogger.Info("Created workflow instance: " + response.Id.ToString() + " for " + item.LogicalName.ToString() + " (" + request.EntityId.ToString() + ") and workflow " + request.WorkflowId.ToString());
                            }
                            catch (Exception ex)
                            {
                                _defaultLogger.Error(ex);
                            }

                        }
                    }
                    catch (Exception ex)
                    {
                        _defaultLogger.Error(ex);
                    }
                }
            }
        }
        private static void CreateSendPendingEmailsViaSMTP(string args, XDocument document, XElement config)
        {

            try
            {
                var getNode = document.Element("Config")
                                .Element("crmconnections")
                                .Elements()
                                .Where(x => x.Attribute("id").Value.ToLower() == args.ToLower()
                                         && x.Attribute("execute").Value.ToLower() == "true")
                                .FirstOrDefault();

                if (getNode != null)
                {
                    _defaultLogger.Info("Connecting to CRM ..." + getNode.ToString());
                    ExecuteSendEmailsViaSMTP(getNode, document, config);

                }
                else
                    _defaultLogger.Error("Missing arguments provided are not valid for running Sending Emails option");
            }
            catch (Exception ex)
            {
                _defaultLogger.Error(ex);
            }
            /*//commenting this as this now is implemented at  parentmethod
             * else
             {
                 //get all crm connections
                 var getNode = document.Element("Config")
                                        .Element("crmconnections")
                                        .Elements()
                                        .Where(x => x.Attribute("execute").Value.ToLower() == "true");
                 if (getNode != null)
                 {
                     foreach (var element in getNode)
                     {
                         try
                         {                      
                             ExecuteSendEmailsViaSMTP(element, document, config);
                         }
                         catch (Exception ex)
                         {
                             _defaultLogger.Error(ex);
                         }

                     }
                 }
                 else
                     _defaultLogger.Info("No crm connections found.");
             }*/
        }
        private static void ExecuteSendEmailsViaSMTP(XElement connectionNode, XDocument document, XElement config)
        {
            try
            {
                var smtpHost = config.Attribute("SMTPServer").Value;
                if (string.IsNullOrEmpty(smtpHost)) throw new Exception("Missing smtp server information. Please add SMTPServer.");
                var connectionString = string.Format("RequireNewInstance={0};Url={1};Username={2};Password={3};authtype={4}",
                            connectionNode.Attribute("requirenewinstance").Value,
                            connectionNode.Attribute("organizationurl").Value,
                            connectionNode.Attribute("crmuserid").Value,
                            DataProtect.DecryptString(connectionNode.Attribute("crmuserpassword").Value),
                            connectionNode.Attribute("authtype").Value);
                bool sendAttachment = connectionNode.Attribute("sendemailattachment") != null ? Convert.ToBoolean(connectionNode.Attribute("sendemailattachment").Value) : false;
                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
                var service = new Microsoft.Xrm.Tooling.Connector.CrmServiceClient(connectionString);

                if (!service.IsReady)
                {
                    _defaultLogger.Error("Could not connect to CRM. " + connectionString + " " + service.LastCrmException);
                }
                else
                {
                    var emailSender = new DefaultSendSmtpEmail(smtpHost, _defaultLogger);
                    var retrieveArgs = new DefaultCrmRetrieveEmailArgs(service, _defaultLogger, document, sendAttachment);
                    var sendSmtpProcess = new SendPendingEmailsViaSMTP(service, emailSender, _defaultLogger, retrieveArgs, document);
                    if (sendSmtpProcess != null)
                    {
                        _defaultLogger.Info("Sending email via SMTP");
                        sendSmtpProcess.Run();
                    }
                }
            }
            catch (Exception ex)
            {
                _defaultLogger.Error(ex);
            }
        }
        private static void FetchAndAssignUserRoleMaping(List<RolesAssign> _lstRoles, string args, XDocument document)
        {
            var getNode = document.Element("Config")
                            .Element("crmconnections")
                            .Elements()
                            .Where(x => x.Attribute("id").Value.ToLower() == args.ToLower())
                            .FirstOrDefault();
            var connectionString = string.Format("RequireNewInstance={0};Url={1};Username={2};Password={3};authtype={4}",
              getNode.Attribute("requirenewinstance").Value,
              getNode.Attribute("organizationurl").Value,
              getNode.Attribute("crmuserid").Value,
              DataProtect.DecryptString(getNode.Attribute("crmuserpassword").Value),
              getNode.Attribute("authtype").Value);

            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
            var service = new Microsoft.Xrm.Tooling.Connector.CrmServiceClient(connectionString);

            if (!service.IsReady)
            {
                _defaultLogger.Error("Could not connect to CRM. " + getNode + " " + service.LastCrmException);
            }
            else
            {
                List<BURoleMapping> _lstBURole = new List<BURoleMapping>();
                var distinctuser = _lstRoles.Select(x => x.Name).Distinct();
                QueryExpression queryUser = new QueryExpression("systemuser");
                queryUser.NoLock = true;
                queryUser.ColumnSet = new ColumnSet("domainname", "businessunitid");
                queryUser.Criteria.AddCondition(new ConditionExpression("domainname", ConditionOperator.In, distinctuser.ToArray()));
                EntityCollection UserCollection = service.RetrieveMultiple(queryUser);
                if (UserCollection != null && UserCollection.Entities != null && UserCollection.Entities.Count > 0)
                {
                    foreach (var item in UserCollection.Entities)
                    {
                        string useremail = item.GetAttributeValue<string>("domainname");
                        var users = _lstRoles.Where(x => x.Name.ToLower() == useremail.ToLower());
                        foreach (var usrItem in users)
                        {
                            usrItem.EntityId = item.Id;
                            usrItem.EntityBuId = item.GetAttributeValue<EntityReference>("businessunitid").Id;
                        }
                    }
                    var distinctRoles = _lstRoles.Select(x => x.RoleName).Distinct();
                    _defaultLogger.Info("Fetching the security roles from CRM...");
                    QueryExpression queryRole = new QueryExpression("role");
                    queryRole.NoLock = true;
                    queryRole.ColumnSet = new ColumnSet("name", "businessunitid");
                    queryRole.Criteria.AddCondition(new ConditionExpression("name", ConditionOperator.In, distinctRoles.ToArray()));
                    EntityCollection RolesCollection = service.RetrieveMultiple(queryRole);
                    if (RolesCollection != null && RolesCollection.Entities != null && RolesCollection.Entities.Count > 0)
                    {
                        foreach (var item in RolesCollection.Entities)
                        {
                            BURoleMapping BUroles = new BURoleMapping();
                            BUroles.RoleName = item.GetAttributeValue<string>("name");
                            BUroles.BUId = item.GetAttributeValue<EntityReference>("businessunitid").Id;
                            BUroles.RoleId = item.Id;
                            _lstBURole.Add(BUroles);

                        }
                        if (_lstBURole.Count > 0)
                        {
                            foreach (var rolItem in _lstRoles)
                            {
                                List<BURoleMapping> _buRole = _lstBURole.Where(i => i.BUId == rolItem.EntityBuId && i.RoleName.ToLower() == rolItem.RoleName.ToLower()).ToList();
                                if (_buRole != null && _buRole.Count > 0)
                                {
                                    rolItem.RoleId = _buRole.FirstOrDefault().RoleId;
                                    AssignRole(rolItem.Flag, rolItem.EntityId, rolItem.RoleId, "systemuser", "systemuserroles_association", service);
                                }
                            }
                        }
                    }
                    else
                        _defaultLogger.Info("Role is empty from CRM. Please check the role names and try again");
                }
            }
        }
        private static void FetchAndAssignTeamRole(string args, List<RolesAssign> _lstRoles, XDocument document)
        {
            var getNode = document.Element("Config")
                            .Element("crmconnections")
                            .Elements()
                            .Where(x => x.Attribute("id").Value.ToLower() == args.ToLower())
                            .FirstOrDefault();
            var connectionString = string.Format("RequireNewInstance={0};Url={1};Username={2};Password={3};authtype={4}",
              getNode.Attribute("requirenewinstance").Value,
              getNode.Attribute("organizationurl").Value,
              getNode.Attribute("crmuserid").Value,
              DataProtect.DecryptString(getNode.Attribute("crmuserpassword").Value),
              getNode.Attribute("authtype").Value);

            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
            var service = new Microsoft.Xrm.Tooling.Connector.CrmServiceClient(connectionString);

            if (!service.IsReady)
            {
                _defaultLogger.Error("Could not connect to CRM. " + getNode + " " + service.LastCrmException);
            }
            else
            {
                List<BURoleMapping> _lstBURole = new List<BURoleMapping>();
                var distinctuser = _lstRoles.Select(x => x.Name).Distinct();
                QueryExpression queryTeam = new QueryExpression("team");
                queryTeam.NoLock = true;
                queryTeam.ColumnSet = new ColumnSet("name", "businessunitid");
                queryTeam.Criteria.AddCondition(new ConditionExpression("name", ConditionOperator.In, distinctuser.ToArray()));
                queryTeam.Criteria.AddCondition(new ConditionExpression("teamtype", ConditionOperator.Equal, 0));//owner teams only
                EntityCollection UserCollection = service.RetrieveMultiple(queryTeam);
                if (UserCollection != null && UserCollection.Entities != null && UserCollection.Entities.Count > 0)
                {
                    foreach (var item in UserCollection.Entities)
                    {
                        string useremail = item.GetAttributeValue<string>("name");
                        var users = _lstRoles.Where(x => x.Name.ToLower() == useremail.ToLower());
                        foreach (var usrItem in users)
                        {
                            usrItem.EntityId = item.Id;
                            usrItem.EntityBuId = item.GetAttributeValue<EntityReference>("businessunitid").Id;
                        }
                    }
                    var distinctRoles = _lstRoles.Select(x => x.RoleName).Distinct();
                    _defaultLogger.Info("Fetching the security roles from CRM...");
                    QueryExpression queryRole = new QueryExpression("role");
                    queryRole.NoLock = true;
                    queryRole.ColumnSet = new ColumnSet("name", "businessunitid");
                    queryRole.Criteria.AddCondition(new ConditionExpression("name", ConditionOperator.In, distinctRoles.ToArray()));
                    EntityCollection RolesCollection = service.RetrieveMultiple(queryRole);
                    if (RolesCollection != null && RolesCollection.Entities != null && RolesCollection.Entities.Count > 0)
                    {
                        foreach (var item in RolesCollection.Entities)
                        {
                            BURoleMapping BUroles = new BURoleMapping();
                            BUroles.RoleName = item.GetAttributeValue<string>("name");
                            BUroles.BUId = item.GetAttributeValue<EntityReference>("businessunitid").Id;
                            BUroles.RoleId = item.Id;
                            _lstBURole.Add(BUroles);

                        }
                        if (_lstBURole.Count > 0)
                        {
                            foreach (var rolItem in _lstRoles)
                            {
                                _defaultLogger.Info("Assigning the role " + rolItem.RoleName + " to the team : " + rolItem.Name);
                                List<BURoleMapping> _buRole = _lstBURole.Where(i => i.BUId == rolItem.EntityBuId && i.RoleName.ToLower() == rolItem.RoleName.ToLower()).ToList();
                                if (_buRole != null && _buRole.Count > 0)
                                {
                                    rolItem.RoleId = _buRole.FirstOrDefault().RoleId;
                                    AssignRole(rolItem.Flag, rolItem.EntityId, rolItem.RoleId, "team", "teamroles_association", service);
                                }
                                else
                                {
                                    _defaultLogger.Info("Role Id returned null for role :" + rolItem.RoleName);
                                }
                            }
                        }
                    }
                    else
                        _defaultLogger.Info("Role is empty from CRM. Please check the role names and try again");
                }
            }
        }
        public static void AssignRole(string flg, Guid referenceId, Guid RoleId, string EntityName, String RelationShipName, CrmServiceClient service)
        {
            try
            {
                if (flg.ToLower() == "add")
                {
                    service.Associate(
         EntityName,
            referenceId,
            new Relationship(RelationShipName),
            new EntityReferenceCollection() { new EntityReference("role", RoleId) });
                }
                else if (flg.ToLower() == "remove")
                {
                    service.Disassociate(
            EntityName,
            referenceId,
            new Relationship(RelationShipName),
            new EntityReferenceCollection() { new EntityReference("role", RoleId) });
                }
            }
            catch (Exception ex)
            {
                _defaultLogger.Error(ex);
            }
        }
        public static void RestartAsyncOperationsOnFetch(string args, XDocument document, string fetchXml)
        {
            var getNode = document.Element("Config")
                .Element("crmconnections")
                .Elements()
                .Where(x => x.Attribute("id").Value.ToLower() == args.ToLower())
                .FirstOrDefault();
            var connectionString = string.Format("RequireNewInstance={0};Url={1};Username={2};Password={3};authtype={4}",
                getNode.Attribute("requirenewinstance").Value,
                getNode.Attribute("organizationurl").Value,
                getNode.Attribute("crmuserid").Value,
                DataProtect.DecryptString(getNode.Attribute("crmuserpassword").Value),
                getNode.Attribute("authtype").Value);

            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
            var service = new Microsoft.Xrm.Tooling.Connector.CrmServiceClient(connectionString);

            if (!service.IsReady)
            {
                _defaultLogger.Error("Could not connect to CRM. " + getNode + " " + service.LastCrmException);
            }
            else
            {
                fetchXml = ReplaceGlobalVariables(fetchXml, document);
                EntityCollection recordsToProcess = service.RetrieveMultiple(new FetchExpression(fetchXml));
                if (recordsToProcess != null && recordsToProcess.Entities != null && recordsToProcess.Entities.Count > 0)
                {
                    try
                    {
                        _defaultLogger.Info("Fetch retrieved " + recordsToProcess.Entities.Count + " records. " + fetchXml);
                        foreach (var item in recordsToProcess.Entities)
                        {
                            //only status and postponeuntil attriubutes of async operations are editable
                            Entity asyncOpn = new Entity("asyncoperation");
                            asyncOpn["asyncoperationid"] = item.Id;
                            asyncOpn["statecode"] = new OptionSetValue(0);//set state to ready
                            asyncOpn["statuscode"] = new OptionSetValue(0);

                            try
                            {
                                service.Update(asyncOpn);
                                _defaultLogger.Info("Restarted async operations for item.Id " + item.Id);
                            }
                            catch (Exception ex)
                            {
                                _defaultLogger.Error(ex);
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        _defaultLogger.Error(ex);
                    }



                }
                else
                    _defaultLogger.Info("Fetch retrieved zero records.");
            }
        }

        #region DeleteRecordsOnFetch
        public static void DeleteRecordsOnFetch (string args, XDocument document, string fetchXml)
        {
            var getNode = document.Element("Config")
                            .Element("crmconnections")
                            .Elements()
                            .Where(x => x.Attribute("id").Value.ToLower() == args.ToLower())
                            .FirstOrDefault();
            var connectionString = string.Format("RequireNewInstance={0};Url={1};Username={2};Password={3};authtype={4}",
              getNode.Attribute("requirenewinstance").Value,
              getNode.Attribute("organizationurl").Value,
              getNode.Attribute("crmuserid").Value,
              DataProtect.DecryptString(getNode.Attribute("crmuserpassword").Value),
              getNode.Attribute("authtype").Value);

            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
            var service = new Microsoft.Xrm.Tooling.Connector.CrmServiceClient(connectionString);

            if (!service.IsReady)
            {
                _defaultLogger.Error("Could not connect to CRM. " + getNode + " " + service.LastCrmException);
            }
            else
            {
                // EntityCollection _recordsToDelete = service.RetrieveMultiple(new FetchExpression(fetchXml));

                //  EntityCollection _recordsToDelete = RetrieveAllRecords(service, fetchXml); 
                fetchXml = ReplaceGlobalVariables(fetchXml, document);
                EntityCollection _recordsToDelete = new EntityCollection(RetrieveAllRecords(service, fetchXml));
                _defaultLogger.Info("Fetch retrieved " + _recordsToDelete.TotalRecordCount + " records. " + fetchXml);
             
                int countOfDeletedRecords = 0;
           
                int countOfFailedDeletions = 0;
                if (_recordsToDelete != null && _recordsToDelete.Entities != null && _recordsToDelete.Entities.Count > 0)
                {

                    foreach (var item in _recordsToDelete.Entities)
                    {
                        //only status and postponeuntil attriubutes of async operations are editable
                        try
                        {
                                                  
                             service.Delete(item.LogicalName, item.Id);
                             _defaultLogger.Info("Deleted record " + item.Id + " from entity " + item.LogicalName);                           
                             countOfDeletedRecords++;
                           
                        }
                        catch (Exception ex)
                        {
                            countOfFailedDeletions += 1;
                            _defaultLogger.Error("For " + item.LogicalName + ", and " + item.Id + ": " + ex.Message);
                        }

                    }

                    _defaultLogger.Info("Total records deleted \n" + countOfDeletedRecords);
                   
                    _defaultLogger.Info("Total number of failures in record deletion \n" + countOfFailedDeletions);
                }
                else
                    _defaultLogger.Info("Fetch retrieved zero records.");
            }
        }
        public static List<Entity> RetrieveAllRecords(IOrganizationService service, string fetchXml)
        {
            var moreRecords = false;
            int pageNumber = 1;
            int fetchCount = 5000;
            var pagingCookie = string.Empty;
            List<Entity> Entities = new List<Entity>();
            do
            {
                //  var xml = string.Format(fetch, cookie);
                var xml= CreateXml(fetchXml, pagingCookie, pageNumber, fetchCount);
                var collection = service.RetrieveMultiple(new FetchExpression(xml));

                if (collection.Entities != null && collection.Entities.Count >= 0) Entities.AddRange(collection.Entities);

                moreRecords = collection.MoreRecords;
                if (moreRecords)
                {
                    pageNumber++;
                    // Set the paging cookie to the paging cookie returned from current results.                            
                    pagingCookie = collection.PagingCookie;
                    //cookie = string.Format("paging-cookie='{0}' page='{1}'", System.Security.SecurityElement.Escape(collection.PagingCookie), page);
                }
            } while (moreRecords);

            return Entities;
        }
        public static string CreateXml(string xml, string cookie, int page, int count)
        {
            StringReader stringReader = new StringReader(xml);
            XmlTextReader reader = new XmlTextReader(stringReader);

            // Load document
            XmlDocument doc = new XmlDocument();
            doc.Load(reader);

            return CreateXml(doc, cookie, page, count);
        }
        public static string CreateXml(XmlDocument doc, string cookie, int page, int count)
        {
            XmlAttributeCollection attrs = doc.DocumentElement.Attributes;

            if (cookie != null)
            {
                XmlAttribute pagingAttr = doc.CreateAttribute("paging-cookie");
                pagingAttr.Value = cookie;
                attrs.Append(pagingAttr);
            }

            XmlAttribute pageAttr = doc.CreateAttribute("page");
            pageAttr.Value = System.Convert.ToString(page);
            attrs.Append(pageAttr);

            XmlAttribute countAttr = doc.CreateAttribute("count");
            countAttr.Value = System.Convert.ToString(count);
            attrs.Append(countAttr);

            StringBuilder sb = new StringBuilder(1024);
            StringWriter stringWriter = new StringWriter(sb);

            XmlTextWriter writer = new XmlTextWriter(stringWriter);
            doc.WriteTo(writer);
            writer.Close();

            return sb.ToString();
        }
        public static List<Entity> RetrieveAllRecords(IOrganizationService service, QueryExpression qe)
        {
            var moreRecords = false;
            qe.PageInfo = new PagingInfo();
            qe.PageInfo.Count = 5000;
            qe.PageInfo.PageNumber = 1;
            // The current paging cookie. When retrieving the first page, 
            // pagingCookie should be null.
            qe.PageInfo.PagingCookie = null;
            List<Entity> Entities = new List<Entity>();
            do
            {

                var collection = service.RetrieveMultiple(qe);

                if (collection.Entities != null && collection.Entities.Count >= 0) Entities.AddRange(collection.Entities);

                moreRecords = collection.MoreRecords;
                if (moreRecords)
                {
                    // Increment the page number to retrieve the next page.
                    qe.PageInfo.PageNumber++;
                    // Set the paging cookie to the paging cookie returned from current results.
                    qe.PageInfo.PagingCookie = collection.PagingCookie;
                }
            } while (moreRecords);

            return Entities;
        }
        private static List<Microsoft.Xrm.Sdk.Metadata.OneToManyRelationshipMetadata> GetAllRelationships(Entity entityObject, CrmServiceClient service)
        {
            RetrieveEntityRequest retrieveAllRelationshipsRequest = new RetrieveEntityRequest

            {

                EntityFilters = EntityFilters.Relationships,

                LogicalName = entityObject.LogicalName,

                RetrieveAsIfPublished = false

            };

            RetrieveEntityResponse retrieveAllRelationshipsResponse = (RetrieveEntityResponse)service.Execute(retrieveAllRelationshipsRequest);

            var oneToNRelationships = retrieveAllRelationshipsResponse.EntityMetadata.OneToManyRelationships;

            var customRelationShips = oneToNRelationships.Where(x => x.IsCustomizable.Value == true && x.CascadeConfiguration.Delete != CascadeType.Cascade).ToList();


            return customRelationShips;


        }

        #endregion

        #region UserPositionManagement
        public static void MigratePositions(string args, List<UserPositionMapping> _lstInputData, XDocument document)
        {
            var getNode = document.Element("Config")
                   .Element("crmconnections")
                   .Elements()
                   .Where(x => x.Attribute("id").Value.ToLower() == args.ToLower())
                   .FirstOrDefault();
            var connectionString = string.Format("RequireNewInstance={0};Url={1};Username={2};Password={3};authtype={4}",
              getNode.Attribute("requirenewinstance").Value,
              getNode.Attribute("organizationurl").Value,
              getNode.Attribute("crmuserid").Value,
              DataProtect.DecryptString(getNode.Attribute("crmuserpassword").Value),
              getNode.Attribute("authtype").Value);
            _defaultLogger.Info("Connecting to CRM....");
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
            CrmServiceClient service = new Microsoft.Xrm.Tooling.Connector.CrmServiceClient(connectionString);

            if (!service.IsReady)
            {
                _defaultLogger.Error("Could not connect to CRM. " + getNode + " " + service.LastCrmException);
                _defaultLogger.Info("Could not connect to CRM. " + getNode + " " + service.LastCrmException);
            }
            else
            {
                _defaultLogger.Info("Connection Established..");
                var distinctuser = _lstInputData.Select(x => x.UserName).Distinct();
                var distinctPositions = _lstInputData.Select(x => x.PositionName).Distinct();
                // Query using the paging cookie.
                // Define the paging attributes.
                // The number of records per page to retrieve.
                int queryCount = 5000;
                // Initialize the page number.
                int pageNumber = 1;
                // Initialize the number of records.
                QueryExpression queryUser = new QueryExpression("systemuser");
                queryUser.NoLock = true;
                queryUser.ColumnSet = new ColumnSet("domainname", "positionid");
                queryUser.Criteria.AddCondition(new ConditionExpression("domainname", ConditionOperator.In, distinctuser.ToArray()));
                // Assign the pageinfo properties to the query expression.
                queryUser.PageInfo = new PagingInfo();
                queryUser.PageInfo.Count = queryCount;
                queryUser.PageInfo.PageNumber = pageNumber;

                // The current paging cookie. When retrieving the first page, 
                // pagingCookie should be null.
                queryUser.PageInfo.PagingCookie = null;
                while (true)
                {
                    EntityCollection UserCollection = service.RetrieveMultiple(queryUser);
                    if (UserCollection != null && UserCollection.Entities != null && UserCollection.Entities.Count > 0)
                    {
                        foreach (var item in UserCollection.Entities)
                        {
                            string useremail = item.GetAttributeValue<string>("domainname");
                            EntityReference CurrentPosition = item.Contains("positionid") ? item.GetAttributeValue<EntityReference>("positionid") : null;
                            var users = _lstInputData.Where(x => x.UserName.ToLower() == useremail.ToLower());
                            foreach (var usrItem in users)
                            {
                                usrItem.User = item.ToEntityReference();
                                usrItem.CurrentMainPosition = CurrentPosition;
                            }
                        }
                    }
                    // Check for more records, if it returns true.
                    if (UserCollection.MoreRecords)
                    {
                        _defaultLogger.Info("\n****************\nPage number {0}\n****************", queryUser.PageInfo.PageNumber);
                        // Increment the page number to retrieve the next page.
                        queryUser.PageInfo.PageNumber++;
                        // Set the paging cookie to the paging cookie returned from current results.
                        queryUser.PageInfo.PagingCookie = UserCollection.PagingCookie;
                    }
                    else
                    {
                        // If no more records are in the result nodes, exit the loop.
                        break;
                    }
                }
                QueryExpression queryPosition = new QueryExpression("position");
                queryPosition.NoLock = true;
                queryPosition.ColumnSet = new ColumnSet("name");
                queryPosition.Criteria.AddCondition(new ConditionExpression("name", ConditionOperator.In, distinctPositions.ToArray()));
                // Assign the pageinfo properties to the query expression.
                queryPosition.PageInfo = new PagingInfo();
                queryPosition.PageInfo.Count = queryCount;
                queryPosition.PageInfo.PageNumber = pageNumber;

                // The current paging cookie. When retrieving the first page, 
                // pagingCookie should be null.
                queryPosition.PageInfo.PagingCookie = null;
                while (true)
                {
                    EntityCollection PositionCollection = service.RetrieveMultiple(queryPosition);
                    if (PositionCollection != null && PositionCollection.Entities != null && PositionCollection.Entities.Count > 0)
                    {
                        foreach (var item in PositionCollection.Entities)
                        {
                            string positionName = item.GetAttributeValue<string>("name");
                            var positions = _lstInputData.Where(x => x.PositionName.ToLower() == positionName.ToLower());
                            foreach (var postItem in positions)
                            {
                                postItem.Postion = item.ToEntityReference();
                            }
                        }
                    }
                    // Check for more records, if it returns true.
                    if (PositionCollection.MoreRecords)
                    {
                        _defaultLogger.Info("\n****************\nPage number {0}\n****************", queryPosition.PageInfo.PageNumber);
                        // Increment the page number to retrieve the next page.
                        queryPosition.PageInfo.PageNumber++;
                        // Set the paging cookie to the paging cookie returned from current results.
                        queryPosition.PageInfo.PagingCookie = PositionCollection.PagingCookie;
                    }
                    else
                    {
                        // If no more records are in the result nodes, exit the loop.
                        break;
                    }
                }

                Int32 TotalRecordCount = 0;
                var _lstgrpByUser = _lstInputData.GroupBy(x => new { x.UserName });
                if (_lstgrpByUser != null && _lstgrpByUser.Count() > 0)
                {
                    foreach (var user in _lstgrpByUser)
                    {
                        try
                        {
                            _defaultLogger.Info("Migrating positions for user: " + user.Key);
                            ++TotalRecordCount;
                            _defaultLogger.Info("Migrating Position for: " + TotalRecordCount + " out of " + _lstgrpByUser.Count() + " users");
                            _defaultLogger.Info("Migrating positions for user: " + user.Key);
                            //get the main position
                            var _lstMainPosition = user.Where(x => x.IsMainPosition == true && x.Action == "add").ToList();
                            if (_lstMainPosition != null && _lstMainPosition.FirstOrDefault() != null)

                            {
                                UserPositionLog _logPosition = new UserPositionLog();
                                //creating logs
                                _logPosition.UserName = Convert.ToString(_lstMainPosition.FirstOrDefault().UserName);
                                _logPosition.PositionName = Convert.ToString(_lstMainPosition.FirstOrDefault().PositionName);
                                _logPosition.Action = "Add";
                                _logPosition.IsMainPosition = true;
                                if (_lstMainPosition.FirstOrDefault().Postion != null
                                && _lstMainPosition.FirstOrDefault().Postion.Id != Guid.Empty)
                                {
                                    _defaultLogger.Info("User Name: " + _logPosition.UserName + " Position name: " + _logPosition.PositionName + " Action: " + _logPosition.Action + " Type: Main Position");
                                    if (_lstMainPosition.FirstOrDefault().User != null && _lstMainPosition.FirstOrDefault().User.Id != Guid.Empty)
                                    {
                                        //update main position for the user
                                        try
                                        {
                                            if (_lstMainPosition.FirstOrDefault().CurrentMainPosition == null ||
                                                _lstMainPosition.FirstOrDefault().CurrentMainPosition.Id == Guid.Empty
                                                || _lstMainPosition.FirstOrDefault().CurrentMainPosition.Id != _lstMainPosition.FirstOrDefault().Postion.Id)
                                            {
                                                Entity updateUser = new Entity("systemuser");
                                                updateUser["systemuserid"] = _lstMainPosition.FirstOrDefault().User.Id;
                                                updateUser["positionid"] = _lstMainPosition.FirstOrDefault().Postion;
                                                _logPosition.Status = "success";
                                                service.Update(updateUser);
                                                _defaultLogger.Info("Main position updated for user: " + user.Key + " Position : " + _lstMainPosition.FirstOrDefault().PositionName);
                                            }
                                            else
                                            {
                                                _defaultLogger.Info("Current position is same as the new main position,so update not performed for user " + user.Key);
                                                _logPosition.Status = "Failed";
                                                _logPosition.Reason = "Current position is same as the new main position,so update not performed for user";
                                            }

                                        }
                                        catch (Exception ex)
                                        {
                                            _defaultLogger.Error(ex);
                                            _logPosition.Status = "Failed";
                                            _logPosition.Reason = ex.Message;
                                        }
                                    }
                                    else
                                    {
                                        _defaultLogger.Info("User reference returned empty from CRM");
                                        _logPosition.Status = "Failed";
                                        _logPosition.Reason = "User reference returned empty from CRM. Check the User Domain Name";
                                    }
                                }
                                else
                                {
                                    _defaultLogger.Info("Position reference returned empty from CRM");
                                    _logPosition.Status = "Failed";
                                    _logPosition.Reason = "Position reference returned empty from CRM. Check the position name";

                                }
                                _lstMigrationLog.Add(_logPosition);
                            }

                            else
                            {
                                _defaultLogger.Info("No main position present for the user : " + user.Key);

                            }
                            List<UserPositionMapping> _lstOtherPosition = user.Where(x => x.IsMainPosition == false && x.Action == "add").ToList();
                            if (_lstOtherPosition != null && _lstOtherPosition.Count > 0)
                            {
                                //create positions
                                foreach (var otherPositions in _lstOtherPosition)
                                {
                                    _defaultLogger.Info("Migrating other positions for user: " + user.Key);
                                    UserPositionLog _logPosition = new UserPositionLog();
                                    _logPosition.UserName = otherPositions.UserName;
                                    _logPosition.PositionName = otherPositions.PositionName;
                                    _logPosition.Action = "Add";
                                    _logPosition.IsMainPosition = false;
                                    _defaultLogger.Info("User Name: " + otherPositions.UserName + " Position name: " + otherPositions.PositionName + " Action: " + otherPositions.Action + " Type: Other Position");
                                    if (otherPositions.User != null && otherPositions.User.Id != Guid.Empty)
                                    {
                                        if (otherPositions.Postion != null && otherPositions.Postion.Id != Guid.Empty
                                           )
                                        {
                                            try
                                            {

                                                _defaultLogger.Info("Position name: " + Convert.ToString(otherPositions.PositionName));
                                                Entity AddOtherPosition = new Entity("rbs_userposition");
                                                AddOtherPosition["rbs_userid"] = otherPositions.User;
                                                AddOtherPosition["rbs_positionid"] = otherPositions.Postion;
                                                service.Create(AddOtherPosition);
                                                _logPosition.Status = "success";

                                            }
                                            catch (Exception ex)
                                            {
                                                _defaultLogger.Error(ex);
                                                _logPosition.Status = "Failed";
                                                _logPosition.Reason = ex.Message;
                                            }
                                        }
                                        else
                                        {
                                            _defaultLogger.Info("Other position is empty from CRM for Position name: " + otherPositions.PositionName);
                                            _logPosition.Status = "Failed";
                                            _logPosition.Reason = "Position reference returned empty from CRM. Check the Position Name";
                                        }
                                    }
                                    else
                                    {
                                        _defaultLogger.Info("User reference returned empty from CRM");
                                        _logPosition.Status = "Failed";
                                        _logPosition.Reason = "User reference returned empty from CRM. Check the User Domain Name";
                                    }
                                    _lstMigrationLog.Add(_logPosition);
                                }

                            }
                            else
                            {
                                _defaultLogger.Info("No other positions present for the user : " + user.Key);
                                _defaultLogger.Info("No other positions present for the user : " + user.Key);
                            }
                        }
                        catch (Exception ex)
                        {
                            _defaultLogger.Error(ex);
                        }
                    }
                }
                List<UserPositionMapping> _positionsToRemove = _lstInputData.Where(x => x.Action == "remove").ToList();
                if (_positionsToRemove != null && _positionsToRemove.Count > 0)
                    RemovePositions(_positionsToRemove, service);
                else
                    _defaultLogger.Info("No Positions to be removed");

                if (_lstMigrationLog.Count > 0 && !string.IsNullOrEmpty(exportToExcel) && exportToExcel.ToLower() == "yes")
                {
                    _defaultLogger.Info("\n *****Exporting results to excel*****");
                    CreateExcelFile.CreateExcelDocument(_lstMigrationLog, exportPath);
                    _defaultLogger.Info("*****Export Succeeded*****");
                }
            }
        }

        public static void RemovePositions(List<UserPositionMapping> _lstToRemovepositions, CrmServiceClient service)
        {
            List<UserPositionMapping> _otherPositionsToRemove = _lstToRemovepositions.Where(x => x.Action == "remove" && x.IsMainPosition == false
                                                                 && x.User != null && x.User.Id != Guid.Empty && x.Postion != null && x.Postion.Id != Guid.Empty).ToList();
            if (_otherPositionsToRemove != null && _otherPositionsToRemove.Count > 0)
            {
                var distinctUsers = _otherPositionsToRemove.Where(y => y.User != null && y.User.Id != Guid.Empty).Select(x => x.User.Id).Distinct();
                List<RemovePositionMapping> _lstRemoveOtherPositions = new List<RemovePositionMapping>();
                int queryCount = 5000;
                // Initialize the page number.
                int pageNumber = 1;
                // Initialize the number of records.
                QueryExpression queryUser = new QueryExpression("rbs_userposition");
                queryUser.NoLock = true;
                queryUser.ColumnSet = new ColumnSet("rbs_userid", "rbs_positionid");
                queryUser.Criteria.AddCondition(new ConditionExpression("rbs_userid", ConditionOperator.In, distinctUsers.ToArray()));
                queryUser.PageInfo = new PagingInfo();
                queryUser.PageInfo.Count = queryCount;
                queryUser.PageInfo.PageNumber = pageNumber;
                LinkEntity linkPosition = new LinkEntity("rbs_userposition", "position", "rbs_positionid", "positionid", JoinOperator.LeftOuter);
                linkPosition.EntityAlias = "position";
                linkPosition.Columns = new ColumnSet("name");
                LinkEntity linkUser = new LinkEntity("rbs_userposition", "systemuser", "rbs_userid", "systemuserid", JoinOperator.LeftOuter);
                linkUser.EntityAlias = "user";
                linkUser.Columns = new ColumnSet("domainname");
                queryUser.LinkEntities.Add(linkUser);
                queryUser.LinkEntities.Add(linkPosition);
                queryUser.PageInfo.PagingCookie = null;
                while (true)
                {
                    EntityCollection UserCollection = service.RetrieveMultiple(queryUser);
                    if (UserCollection != null && UserCollection.Entities != null && UserCollection.Entities.Count > 0)
                    {
                        foreach (var item in UserCollection.Entities)
                        {

                            RemovePositionMapping _removemapping = new RemovePositionMapping();
                            _removemapping.User = item.Contains("rbs_userid") ? item.GetAttributeValue<EntityReference>("rbs_userid") : null;
                            _removemapping.Postion = item.Contains("rbs_positionid") ? item.GetAttributeValue<EntityReference>("rbs_positionid") : null;
                            _removemapping.UserPosition = item.Id;
                            _removemapping.PositionName = item.Contains("position.name") ? Convert.ToString(item.GetAttributeValue<AliasedValue>("position.name").Value) : string.Empty;
                            _removemapping.UserName = item.Contains("user.domainname") ? Convert.ToString(item.GetAttributeValue<AliasedValue>("user.domainname").Value) : string.Empty;
                            if (_removemapping.User != null && _removemapping.Postion != null)//list will contain only valid non null values
                                _lstRemoveOtherPositions.Add(_removemapping);
                        }
                    }
                    // Check for more records, if it returns true.
                    if (UserCollection.MoreRecords)
                    {
                        _defaultLogger.Info("\n****************\nPage number {0}\n****************", queryUser.PageInfo.PageNumber);
                        // Increment the page number to retrieve the next page.
                        queryUser.PageInfo.PageNumber++;
                        // Set the paging cookie to the paging cookie returned from current results.
                        queryUser.PageInfo.PagingCookie = UserCollection.PagingCookie;
                    }
                    else
                    {
                        // If no more records are in the result nodes, exit the loop.
                        break;
                    }
                }

                //filter pthe remove list containing all positions of users with only the positions to be removed

                var _finalremoveList = _lstRemoveOtherPositions.Where(x => _otherPositionsToRemove.Any(y => x.Postion.Id == y.Postion.Id && x.User.Id == y.User.Id)).ToList();

                if (_finalremoveList != null && _finalremoveList.Count > 0)
                {
                    foreach (var item in _finalremoveList)
                    {
                        UserPositionLog _logPosition = new UserPositionLog();
                        _logPosition.Action = "remove";
                        _logPosition.IsMainPosition = false;
                        _logPosition.UserName = item.UserName;
                        _logPosition.PositionName = item.PositionName;
                        //delete
                        try
                        {
                            _defaultLogger.Info("Deleteing other position for user : " + item.UserName + " position : " + item.PositionName);
                            service.Delete("rbs_userposition", item.UserPosition);
                            _logPosition.Status = "success";
                        }
                        catch (Exception ex)
                        {
                            _defaultLogger.Error("Error when removing user position for user: " + item.UserName + " and position: " + item.PositionName + ". " + ex.Message);
                            _logPosition.Status = "Failed";
                            _logPosition.Reason = ex.Message;
                        }
                        _lstMigrationLog.Add(_logPosition);
                    }
                }
            }
            else
            {
                _defaultLogger.Info("No valid other psoitions to remove");
                _defaultLogger.Info("No Valid users or other positions to remove");
            }
            //just for logging purposes get the records with action remove that had invalid users or positions
            List<UserPositionMapping> _otherPositionsInvalidData = _lstToRemovepositions.Where(x => (x.Action == "remove") &&
                                                          (x.User == null || x.Postion == null || x.User.Id == Guid.Empty || x.Postion.Id == Guid.Empty)).ToList();
            if (_otherPositionsInvalidData != null && _otherPositionsInvalidData.Count > 0)
            {
                foreach (var _logItems in _otherPositionsInvalidData)
                {
                    UserPositionLog _logPosition = new UserPositionLog();
                    _logPosition.Action = "remove";
                    _logPosition.IsMainPosition = _logItems.IsMainPosition;
                    _logPosition.UserName = _logItems.UserName;
                    _logPosition.PositionName = _logItems.PositionName;
                    if (_logItems.User == null || _logItems.User.Id == Guid.Empty)
                    {
                        _logPosition.Status = "failed";
                        _logPosition.Reason = "User Reference is null. Check the suer Domanin name given";
                        _defaultLogger.Info(" Error : In removing user position for user: " + _logItems.UserName + " position : " + _logItems.PositionName + " User Reference is null");
                    }
                    if ((_logItems.Postion == null || _logItems.Postion.Id == Guid.Empty) && _logItems.IsMainPosition == false)
                    {
                        _logPosition.Status = "failed";
                        _logPosition.Reason = "Position Reference is null from CRM. Check the Input Position Name";
                        _defaultLogger.Info(" Error : In removing user position for user: " + _logItems.UserName + " position : " + _logItems.PositionName + " Position Reference is null");
                    }
                    //for clearing main position no need to mention position name, so if position name is empty in that case, that is not an error
                    //need not add it to the error log
                    if ((_logItems.IsMainPosition == true) && (_logItems.User == null || _logItems.User.Id == Guid.Empty))
                        _lstMigrationLog.Add(_logPosition);
                    if (_logItems.IsMainPosition == false)
                        _lstMigrationLog.Add(_logPosition);
                }
            }

            //Removing Main Position 
            List<UserPositionMapping> _mainPositionsToRemove = _lstToRemovepositions.Where(x => x.Action == "remove" && x.IsMainPosition == true
                                                                 && x.User != null && x.User.Id != Guid.Empty).ToList();
            if (_mainPositionsToRemove != null && _mainPositionsToRemove.Count > 0)
            {
                foreach (var _mainPosition in _mainPositionsToRemove)
                {
                    UserPositionLog _logPosition = new UserPositionLog();
                    _logPosition.Action = "remove";
                    _logPosition.IsMainPosition = true;
                    _logPosition.UserName = _mainPosition.UserName;
                    _logPosition.PositionName = _mainPosition.PositionName;
                    try
                    {
                        Entity user = new Entity("systemuser");
                        user["systemuserid"] = _mainPosition.User.Id;
                        user["positionid"] = null;
                        service.Update(user);
                        _logPosition.Status = "success";
                    }
                    catch (Exception ex)
                    {
                        _defaultLogger.Error("Error when removing main position for user: " + _mainPosition.UserName + " and position : " + _mainPosition.PositionName + ". " + ex.Message);
                        _logPosition.Status = "Failed";
                        _logPosition.Reason = ex.Message;
                    }
                    _lstMigrationLog.Add(_logPosition);
                }
            }
        }

        #endregion

        #region RootBusinessUnitRename
        public static void RootBusinessUnitRename(string args, XDocument document, string newBUName)
        {
            var getNode = document.Element("Config")
                            .Element("crmconnections")
                            .Elements()
                            .Where(x => x.Attribute("id").Value.ToLower() == args.ToLower())
                            .FirstOrDefault();
            var connectionString = string.Format("RequireNewInstance={0};Url={1};Username={2};Password={3};authtype={4}",
              getNode.Attribute("requirenewinstance").Value,
              getNode.Attribute("organizationurl").Value,
              getNode.Attribute("crmuserid").Value,
              DataProtect.DecryptString(getNode.Attribute("crmuserpassword").Value),
              getNode.Attribute("authtype").Value);

            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
            var service = new Microsoft.Xrm.Tooling.Connector.CrmServiceClient(connectionString);

            if (!service.IsReady)
            {
                _defaultLogger.Error("Could not connect to CRM. " + getNode + " " + service.LastCrmException);
            }
            else
            {

                string sFetch = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                <entity name='businessunit'>                                
                                <attribute name='businessunitid' />
                                <filter type='and'>
                                    <condition attribute='parentbusinessunitid' operator='null' />
                                </filter>
                                </entity>
                            </fetch>";

                EntityCollection enBUs = service.RetrieveMultiple(new FetchExpression(sFetch));

                if (enBUs != null && enBUs.Entities != null && enBUs.Entities.Count > 0)
                {
                    Entity enBUToUpdate = new Entity(enBUs.Entities[0].LogicalName, enBUs.Entities[0].Id);
                    enBUToUpdate.Attributes["name"] = newBUName;

                    service.Update(enBUToUpdate);

                    _defaultLogger.Info("Root BU Name renamed to " + newBUName);
                }
            }
        }

        #endregion

        #region RemovePositionsWhenUserIsInactive
        private static void RemovePositionsOnFetch(string args, string fetchXml, XDocument document)
        {

            var getNode = document.Element("Config")
                            .Element("crmconnections")
                            .Elements()
                             .Where(x => x.Attribute("id").Value.ToLower() == args.ToLower())
                            .FirstOrDefault();
            var connectionString = string.Format("RequireNewInstance={0};Url={1};Username={2};Password={3};authtype={4}",
              getNode.Attribute("requirenewinstance").Value,
              getNode.Attribute("organizationurl").Value,
              getNode.Attribute("crmuserid").Value,
              DataProtect.DecryptString(getNode.Attribute("crmuserpassword").Value),
              getNode.Attribute("authtype").Value);

            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
            var service = new CrmServiceClient(connectionString);

            if (!service.IsReady)
            {
                _defaultLogger.Error("Could not connect to CRM. " + getNode + " " + service.LastCrmException);
            }
            else
            {
                fetchXml = ReplaceGlobalVariables(fetchXml, document);
                EntityCollection _recordsToRemovePositions = service.RetrieveMultiple(new FetchExpression(fetchXml));
                //   Entity entityTobeDeleted = new Entity(_recordsToRemovePositions.EntityName);
                int countOfSuccesfulUpdations = 0;

                int countOfFailedUpdations = 0;

                if (_recordsToRemovePositions != null && _recordsToRemovePositions.Entities != null && _recordsToRemovePositions.Entities.Count > 0)
                {


                    try
                    {
                        foreach (var item in _recordsToRemovePositions.Entities)
                        {

                            Position currentItem = new Position();


                            if (item.Attributes.Contains("positionid") && item.Attributes["positionid"] != null)
                            {
                                currentItem.hasPositionId = true;
                            }
                            ////rbs_positionid" 
                            if (item.Attributes.Contains("rbs_positionid") && item.Attributes["rbs_positionid"] != null)
                            {
                                currentItem.hasUserPositionId = true;
                            }

                            if (!userPositionDictionary.ContainsKey(item.Id))
                                userPositionDictionary.Add(item.GetAttributeValue<Guid>("systemuserid"), currentItem);
                            else
                            {
                                Position tempPosition = userPositionDictionary[item.Id];

                                tempPosition.hasPositionId = currentItem.hasPositionId;

                                tempPosition.hasUserPositionId = currentItem.hasUserPositionId;

                                userPositionDictionary[item.Id] = tempPosition;
                            }


                        }
                        if (userPositionDictionary != null && userPositionDictionary.Count > 0)
                        {
                            _defaultLogger.Info("Total " + userPositionDictionary.Count + " records to be updated \n");

                            bool removeMainPosition = false;

                            bool removeOtherPosition = false;


                            foreach (var pair in userPositionDictionary)
                            {
                                bool hasUserPositionId = pair.Value.hasUserPositionId;

                                bool hasPositionId = pair.Value.hasPositionId;

                                if (hasPositionId)
                                {
                                    removeMainPosition = RemoveMainPosition(service, pair.Key);
                                }
                                if (hasUserPositionId)
                                {
                                    removeOtherPosition = RemoveOtherPosition(service, pair.Key);
                                }

                                if (hasPositionId && removeMainPosition)
                                {
                                    countOfSuccesfulUpdations++;
                                }
                                else if (hasPositionId && !removeMainPosition)
                                { countOfFailedUpdations += 1; }

                                if (hasUserPositionId && removeOtherPosition)
                                {
                                    countOfSuccesfulUpdations++;

                                }
                                else if (hasUserPositionId && !removeOtherPosition) { countOfFailedUpdations += 1; }

                                removeOtherPosition = false;

                                removeMainPosition = false;
                            }
                        }
                        _defaultLogger.Info("Total " + _recordsToRemovePositions.EntityName + " updations performed \n" + countOfSuccesfulUpdations);

                        _defaultLogger.Info("Total number of failures in position removal \n" + countOfFailedUpdations);
                    }
                    catch (Exception ex)
                    {
                        _defaultLogger.Error(ex);
                    }

                }
                else
                    _defaultLogger.Info("Fetchxml yielded zero results");
            }
        }
        private static bool RemoveOtherPosition(CrmServiceClient service, Guid userId)
        {


            Guid userPositionId = Guid.Empty;

            try
            {
                QueryExpression qeToRetrieveOtherPositions = new QueryExpression("rbs_userposition");

                qeToRetrieveOtherPositions.ColumnSet = new ColumnSet("rbs_positionid");

                qeToRetrieveOtherPositions.Criteria.AddCondition("rbs_userid", ConditionOperator.Equal, userId);

                EntityCollection otherPositions = service.RetrieveMultiple(qeToRetrieveOtherPositions);

                if (otherPositions != null && otherPositions.Entities != null && otherPositions.Entities.Count > 0)
                {
                    foreach (var item in otherPositions.Entities)
                    {
                        userPositionId = item.GetAttributeValue<Guid>("rbs_userpositionid");

                        //service.Disassociate("systemuser", userId, new Relationship("rbs_systemuser_rbs_userposition_UserId"), new EntityReferenceCollection() { new EntityReference("rbs_userposition", userPositionId) });
                        service.Delete("rbs_userposition", userPositionId);

                    }
                }
                return true;
            }
            catch (Exception ex)
            {
                _defaultLogger.Error("Error when removing rbs_userposition: " + userPositionId + " and UserId: " + userId + ". " + ex.Message);
                return false;
            }
        }
        private static bool RemoveMainPosition(CrmServiceClient service, Guid userId)
        {

            try
            {
                Entity User = new Entity("systemuser", userId);

                User.Attributes["positionid"] = null;

                service.Update(User);

                return true;
            }
            catch (Exception ex)
            {
                _defaultLogger.Error("Error while removing position Userid " + userId + ". " + ex.Message);
                return false;
            }
        }

        #endregion

        #region UpdateDataRetentionRecordsAfterPolicyChanges
        private static void UpdateDataRetentionRecordsAfterPolicyChange(string args, string fetchXmlForMOdifications, XDocument document)
        {
            try
            {
                var getNode = document.Element("Config")
                                    .Element("crmconnections")
                                    .Elements()
                                       .Where(x => x.Attribute("id").Value.ToLower() == args.ToLower())
                                    .FirstOrDefault();
                var connectionString = string.Format("RequireNewInstance={0};Url={1};Username={2};Password={3};authtype={4}",
                  getNode.Attribute("requirenewinstance").Value,
                  getNode.Attribute("organizationurl").Value,
                  getNode.Attribute("crmuserid").Value,
                  DataProtect.DecryptString(getNode.Attribute("crmuserpassword").Value),
                  getNode.Attribute("authtype").Value);
               
                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
                var service = new Microsoft.Xrm.Tooling.Connector.CrmServiceClient(connectionString);

                if (!service.IsReady)
                {
                    _defaultLogger.Error("Could not connect to CRM. " + getNode + " " + service.LastCrmException);
                }
                else
                {

                    //Retrieve the updated values of fields in Data Retnention configuration
                    // Entity dataretentionconfiguration = service.Retrieve("rbs_dataretentionconfiguration", entityId, new ColumnSet(true));
                    fetchXmlForMOdifications = ReplaceGlobalVariables(fetchXmlForMOdifications, document);
                    EntityCollection _configurationRecordsUpdated = service.RetrieveMultiple(new FetchExpression(fetchXmlForMOdifications));
                    string PrimaryEntityLogicalName;

                    if (_configurationRecordsUpdated != null && _configurationRecordsUpdated.Entities != null && _configurationRecordsUpdated.Entities.Count > 0)
                    {
                        foreach (var configuration in _configurationRecordsUpdated.Entities)
                        {
                            if (configuration.Attributes.Contains("rbs_entityname") && configuration.Attributes["rbs_entityname"] != null)
                            { PrimaryEntityLogicalName = configuration.GetAttributeValue<string>("rbs_entityname"); }

                            //RETRIEVES ALL RECORDS FROM rbs_dataretentionrecods WHERE rbs_dataretentionrecordconfigurationid = entityId
                            //and status reason of data retentionrecord is "In retention Period"
                            //FOR EACH RECORD
                            //REPLICATES LOGIC IN UpsertDataRetentionRecord TO UPDATE rbs_dataretentionrecord(s) EXCEP 
                            //THAT DO NOT UPDATE 'Action on' rbs_dataretentionrecord.rbs_actionon > =rbs_dataretentionconfiguration.rbs_actionon 

                            QueryExpression qeForRelatedDataRetentionRecords = new QueryExpression("rbs_dataretentionrecord");
                            qeForRelatedDataRetentionRecords.Criteria.AddFilter(LogicalOperator.And);
                            qeForRelatedDataRetentionRecords.Criteria.AddCondition("rbs_dataretentionconfigurationid", ConditionOperator.Equal, configuration.Id);
                            qeForRelatedDataRetentionRecords.Criteria.AddCondition(new ConditionExpression("statuscode", ConditionOperator.Equal, 1));

                            EntityCollection dataRetentionRecordsAssociatedWithPolicy = new EntityCollection(RetrieveAllRecords(service, qeForRelatedDataRetentionRecords));


                            if (dataRetentionRecordsAssociatedWithPolicy != null && dataRetentionRecordsAssociatedWithPolicy.Entities != null && dataRetentionRecordsAssociatedWithPolicy.Entities.Count > 0)
                            {

                                EntityCollection toBeUpdatedDataRetentionRecordsAssociatedWithPolicy = CalculateValuesToBeUpdated(dataRetentionRecordsAssociatedWithPolicy, configuration, service);
                                int updatedCount = 0;
                                _defaultLogger.Info("Total number of records to be updated " + toBeUpdatedDataRetentionRecordsAssociatedWithPolicy.Entities.Count);

                                foreach (var entity in toBeUpdatedDataRetentionRecordsAssociatedWithPolicy.Entities)
                                {
                                    try
                                    {
                                        service.Update(entity);
                                        updatedCount++;
                                    }
                                    catch (Exception ex)
                                    {
                                        _defaultLogger.Error("Error for entityid: " + entity.Id + ". " + ex.Message);
                                    }
                                }
                                if (toBeUpdatedDataRetentionRecordsAssociatedWithPolicy.Entities.Count != updatedCount)
                                {
                                    int failedCount = dataRetentionRecordsAssociatedWithPolicy.Entities.Count - updatedCount;
                                    _defaultLogger.Info("No.of failed data retention records related to policy change for " + configuration.GetAttributeValue<string>("rbs_entityname") + "are: " + failedCount + ", While " + updatedCount + " succeded");

                                    int o = dataRetentionRecordsAssociatedWithPolicy.Entities.Count - updatedCount;
                                }
                                else
                                {
                                    // No errors means all transactions are successful.
                                    _defaultLogger.Info("All related data retention records related to policy change for " + configuration.GetAttributeValue<string>("rbs_entityname") + "have been updated successfully.");
                                }
                            }


                            else { _defaultLogger.Info("Query Expression for related dataRetentionRecordsAssociatedWithPolicy yielded no results "); }
                        }

                    }
                    else { _defaultLogger.Error("Query Expression for related configuration records yielded no results"); }

                }
            }
            catch (Exception ex)
            {
                _defaultLogger.Error(ex);
            }
            finally
            {

            }

        }

        private static EntityCollection CalculateValuesToBeUpdated(EntityCollection dataRetentionRecordsAssociatedWithPolicy, Entity configurationPolicy, IOrganizationService service)
        {

            int i = 0;
            int? actionAfterX = 0;
            string actionAfterPeriodType = "";
            bool needsToBeUpdated = false;

            DateTime actionOn;

            EntityCollection retentionCollection = new EntityCollection() { EntityName = "rbs_dataretentionrecord" };

            Entity configurationEntityInContext = configurationPolicy;

            foreach (Entity ent in dataRetentionRecordsAssociatedWithPolicy.Entities)
            {
                Entity dataRetentionRecord = service.Retrieve("rbs_dataretentionrecord", dataRetentionRecordsAssociatedWithPolicy.Entities[i].Id, new ColumnSet("rbs_triggerdate", "rbs_actionon"));

                if (configurationEntityInContext.Attributes.Contains("rbs_actionafterx") && configurationEntityInContext.Attributes["rbs_actionafterx"] != null)
                {
                    actionAfterX = Convert.ToInt32(configurationEntityInContext.Attributes["rbs_actionafterx"]);
                }
                if (configurationEntityInContext.Attributes.Contains("rbs_actionafterperiod") && configurationEntityInContext.Attributes["rbs_actionafterperiod"] != null)
                {
                    actionAfterPeriodType = configurationPolicy.FormattedValues["rbs_actionafterperiod"];
                }
                if (configurationEntityInContext.Attributes.Contains("rbs_action") && configurationEntityInContext.Attributes["rbs_action"] != null)
                {
                    bool action = Convert.ToBoolean(configurationEntityInContext.Attributes["rbs_action"]);
                    dataRetentionRecord.Attributes["rbs_action"] = action;
                }
                /*
                if (configurationEntityInContext.Attributes.Contains("rbs_entityname") && configurationEntityInContext.Attributes["rbs_entityname"] != null)
                {
                    RetrieveEntityRequest retrieveEntityRequest = new RetrieveEntityRequest()
                    {
                        LogicalName = configurationEntityInContext.Attributes["rbs_entityname"].ToString(),
                        RetrieveAsIfPublished = false
                    };
                    RetrieveEntityResponse retrieveEntityResponse = (RetrieveEntityResponse)service.Execute(retrieveEntityRequest);
                    bool entityExists = retrieveEntityResponse.EntityMetadata.LogicalName != null ? true : false;
                    if (entityExists) { dataRetentionRecord.Attributes["rbs_entity"] = configurationEntityInContext.Attributes["rbs_entityname"].ToString(); }
                }*/
                if (dataRetentionRecord.GetAttributeValue<DateTime>("rbs_triggerdate") != null)
                {
                    if (actionAfterX == 0)
                    {
                        actionAfterX = Convert.ToInt32(configurationPolicy.GetAttributeValue<int>("rbs_actionafterx"));
                    }

                    actionOn = CalculateRetentionDate(dataRetentionRecord.GetAttributeValue<DateTime>("rbs_triggerdate"), actionAfterX, actionAfterPeriodType);

                    dataRetentionRecord.Attributes["rbs_actionon"] = actionOn;

                    needsToBeUpdated = true;
                    /*
                     if (actionOn >= dataRetentionRecord.GetAttributeValue<DateTime>("rbs_actionon"))
                     {
                         dataRetentionRecord.Attributes["rbs_actionon"] = actionOn;

                         needsToBeUpdated = true;
                     }  }*/

                     }
                    if (needsToBeUpdated == true)
                {
                    retentionCollection.Entities.Add(dataRetentionRecord);
                }

                needsToBeUpdated = false;
                i++;
            }

            return retentionCollection;
        }

        private static DateTime CalculateRetentionDate(DateTime Date, decimal? retainAfterPeriod, string periodType)
        {

            DateTime dateCalculated;
            switch (periodType)
            {
                case "Years":
                    dateCalculated = Date.AddYears(Convert.ToInt16(retainAfterPeriod));
                    break;
                case "Months":
                    dateCalculated = Date.AddMonths(Convert.ToInt16(retainAfterPeriod));
                    break;
                case "Days":
                    dateCalculated = Date.AddDays(Convert.ToInt16(retainAfterPeriod));
                    break;
                case "Hours":
                    dateCalculated = Date.AddHours(Convert.ToInt16(retainAfterPeriod));
                    break;
                case "Minutes":
                    dateCalculated = Date.AddMinutes(Convert.ToInt16(retainAfterPeriod));
                    break;
                case "Seconds":
                    dateCalculated = Date.AddSeconds(Convert.ToInt16(retainAfterPeriod));
                    break;
                default:
                    dateCalculated = new DateTime(2100, 01, 01);
                    break;
            }

            return dateCalculated;


        }

        #endregion

        #region RetrieveJavaScriptEventHandlers

        private static void RetrieveJavaScriptEventHandlers(string args, XDocument document, string entityLogicalName)
        {
            #region Creating CRM service

            var getNode = document.Element("Config")
                            .Element("crmconnections")
                            .Elements()
                            .Where(x => x.Attribute("id").Value.ToLower() == args.ToLower())
                            .FirstOrDefault();
            var connectionString = string.Format("RequireNewInstance={0};Url={1};Username={2};Password={3};authtype={4}",
              getNode.Attribute("requirenewinstance").Value,
              getNode.Attribute("organizationurl").Value,
              getNode.Attribute("crmuserid").Value,
              DataProtect.DecryptString(getNode.Attribute("crmuserpassword").Value),
              getNode.Attribute("authtype").Value);

            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
            var service = new Microsoft.Xrm.Tooling.Connector.CrmServiceClient(connectionString);

            #endregion

            if (!service.IsReady)
            {
                _defaultLogger.Error("Could not connect to CRM. " + getNode + " " + service.LastCrmException);
            }
            else
            {
                QueryExpression query = new QueryExpression("systemform")
                {
                    Distinct = false,
                    ColumnSet = new ColumnSet(true),
                    Criteria =
                    {
                        Filters =
                        {
                            new FilterExpression
                            {
                                FilterOperator = LogicalOperator.And,
                                    Conditions =
                                    {
                                        new ConditionExpression("objecttypecode", ConditionOperator.Equal, entityLogicalName),
                                        new ConditionExpression("type", ConditionOperator.Equal, 2),
                                        new ConditionExpression("iscustomizable", ConditionOperator.Equal, true),
                                        new ConditionExpression("formactivationstate", ConditionOperator.Equal, 1)
                                    }
                            }
                        }
                    }
                };

                EntityCollection systemFormCollection = service.RetrieveMultiple(query);

                WriteInExcel(systemFormCollection, entityLogicalName);
            }
        }

        static void WriteInExcel(EntityCollection systemFormCollection, string entityLogicalname)
        {
            List<JavaScriptEventHandlers> eventHandlersList = new List<JavaScriptEventHandlers>();
            string attributeName = string.Empty;

            foreach (var systemForm in systemFormCollection.Entities)
            {
                var xdoc = XDocument.Parse(systemForm.Attributes["formxml"].ToString());
                var eventsList = xdoc.Descendants("event").ToList();
                var formName = systemForm.Attributes["name"];

                foreach (var item in eventsList)
                {
                    string eventName = item.Attribute("name").Value;
                    if (eventName.ToLower().Equals("onchange"))
                        attributeName = item.Attribute("attribute").Value;
                    else attributeName = string.Empty;

                    foreach (var handler in item.Descendants("Handler"))
                    {
                        var libraryName = handler.Attribute("libraryName").Value;
                        var functionName = handler.Attribute("functionName").Value;
                        var isEventEnabled = handler.Attribute("enabled").Value;
                        eventHandlersList.Add(new JavaScriptEventHandlers { FormName = formName.ToString(), EventName = eventName, LibraryName = libraryName, FunctionName = functionName, AttributeName = attributeName, IsEventEnabled = Convert.ToBoolean(isEventEnabled) });
                    }
                }
            }

            eventHandlersList = eventHandlersList.OrderBy(o1 => o1.FunctionName).OrderBy(o2 => o2.EventName).OrderBy(o3 => o3.AttributeName).OrderBy(o4 => o4.LibraryName).OrderBy(o5 => o5.FormName).ToList();

            CreateExcel(eventHandlersList, entityLogicalname);
        }

        static void CreateExcel(List<JavaScriptEventHandlers> eventHandlersList, string entityLogicalname)
        {
            Excel.Application xlApp;
            Excel.Workbook xlWorkBook;
            Excel.Worksheet xlWorkSheet;

            xlApp = new Excel.Application();
            object misValue = System.Reflection.Missing.Value;

            xlWorkBook = xlApp.Workbooks.Add(misValue);
            xlWorkSheet = (Excel.Worksheet)xlWorkBook.Worksheets.get_Item(1);

            xlWorkSheet.Cells[1, 1] = "Form Name";
            xlWorkSheet.Cells[1, 2] = "Library Name";
            xlWorkSheet.Cells[1, 3] = "Event Name";
            xlWorkSheet.Cells[1, 4] = "Is Event Enabled?";
            xlWorkSheet.Cells[1, 5] = "Attribute Name";
            xlWorkSheet.Cells[1, 6] = "Function Name";

            xlWorkSheet.Cells[1, 1].Font.Bold = true;
            xlWorkSheet.Cells[1, 2].Font.Bold = true;
            xlWorkSheet.Cells[1, 3].Font.Bold = true;
            xlWorkSheet.Cells[1, 4].Font.Bold = true;
            xlWorkSheet.Cells[1, 5].Font.Bold = true;
            xlWorkSheet.Cells[1, 6].Font.Bold = true;

            xlWorkSheet.Columns[1].ColumnWidth = 18;
            xlWorkSheet.Columns[2].ColumnWidth = 18;
            xlWorkSheet.Columns[3].ColumnWidth = 18;
            xlWorkSheet.Columns[4].ColumnWidth = 18;
            xlWorkSheet.Columns[5].ColumnWidth = 18;
            xlWorkSheet.Columns[6].ColumnWidth = 30;

            for (int row = 0; row < eventHandlersList.Count; row++)
            {
                xlWorkSheet.Cells[row + 2, 1] = eventHandlersList[row].FormName;
                xlWorkSheet.Cells[row + 2, 2] = eventHandlersList[row].LibraryName;
                xlWorkSheet.Cells[row + 2, 3] = eventHandlersList[row].EventName;
                xlWorkSheet.Cells[row + 2, 4] = eventHandlersList[row].IsEventEnabled;
                xlWorkSheet.Cells[row + 2, 5] = eventHandlersList[row].AttributeName;
                xlWorkSheet.Cells[row + 2, 6] = eventHandlersList[row].FunctionName;
            }

            xlWorkBook.SaveAs(Directory.GetCurrentDirectory() + "Event Handlers - " + entityLogicalname + ".xlsx", Excel.XlFileFormat.xlOpenXMLWorkbook, misValue, misValue, misValue, misValue,
                Excel.XlSaveAsAccessMode.xlExclusive, misValue, misValue, misValue, misValue, misValue);

            xlWorkBook.Close(true);
            xlApp.Quit();

            Marshal.ReleaseComObject(xlWorkSheet);
            Marshal.ReleaseComObject(xlWorkBook);
            Marshal.ReleaseComObject(xlApp);
        }

        #endregion

        #region BusinessUnitSetIIQEnabled
        public static void BusinessUnitSetIIQEnabled(string args, XDocument document, string BUName, string iiqEnabledFieldName, bool iiqEnabled)
        {
            var getNode = document.Element("Config")
                            .Element("crmconnections")
                            .Elements()
                            .Where(x => x.Attribute("id").Value.ToLower() == args.ToLower())
                            .FirstOrDefault();
            var connectionString = string.Format("RequireNewInstance={0};Url={1};Username={2};Password={3};authtype={4}",
              getNode.Attribute("requirenewinstance").Value,
              getNode.Attribute("organizationurl").Value,
              getNode.Attribute("crmuserid").Value,
              DataProtect.DecryptString(getNode.Attribute("crmuserpassword").Value),
              getNode.Attribute("authtype").Value);

            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
            var service = new Microsoft.Xrm.Tooling.Connector.CrmServiceClient(connectionString);

            if (!service.IsReady)
            {
                _defaultLogger.Error("Could not connect to CRM. " + getNode + " " + service.LastCrmException);
            }
            else
            {
                _defaultLogger.Info("Trying to Set IIQEnabled field on Business Unit");

                string sFetch = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                <entity name='businessunit'>                                
                                <attribute name='businessunitid' />
                                <filter type='and'>
                                    <condition attribute='name' operator='eq' value='{0}' />
                                </filter>
                                </entity>
                            </fetch>";

                EntityCollection enBUs = service.RetrieveMultiple(new FetchExpression(string.Format(sFetch, BUName)));

                if (enBUs != null && enBUs.Entities != null && enBUs.Entities.Count > 0)
                {
                    Entity enBUToUpdate = new Entity(enBUs.Entities[0].LogicalName, enBUs.Entities[0].Id);
                    enBUToUpdate.Attributes[iiqEnabledFieldName] = iiqEnabled;

                    service.Update(enBUToUpdate);

                    _defaultLogger.Info("IIQEnabled is set to {0} on BU - {1}", iiqEnabled, BUName);
                }
            }
        }

        #endregion

        #region helper methods for last Execution Date
        private static string ReplaceGlobalVariables(string fetchXml, XDocument document)
        {
            DateTime lastExecution = DateTime.UtcNow;
            if (document.Element("Config").Element("Variables") != null)
            {
                var getLastExecutionTimeNode = document.Element("Config")
                      .Element("Variables")
                      .Elements();
                if (getLastExecutionTimeNode.Any())
                {
                    if (getLastExecutionTimeNode.FirstOrDefault().Name.ToString().ToLower() == "lastexecutiondatetime" && !string.IsNullOrEmpty(getLastExecutionTimeNode.FirstOrDefault().Value))
                    {
                        lastExecution = Convert.ToDateTime(getLastExecutionTimeNode.FirstOrDefault().Value);
                    }
                }
            }
            if (fetchXml.Contains("@LastExecutionDateTime"))
            {
                fetchXml = fetchXml.Replace("@LastExecutionDateTime", lastExecution.ToString("s"));
            }
            if (fetchXml.Contains("@DateTime.UtcNow"))
            {
                fetchXml = fetchXml.Replace("@DateTime.UtcNow", DateTime.UtcNow.ToString("s"));
            }
            return fetchXml;
        }
        public static void SaveXmlDocument(XDocument document, string docPath)
        {
            if (document.Element("Config").Element("Variables") != null)
            {

                var getLastExecutionTimeNode = document.Element("Config")
                  .Element("Variables")
                  .Elements();

                if (getLastExecutionTimeNode.Any() && getLastExecutionTimeNode.Where(x => x.Name.LocalName.ToLower() == "lastexecutiondatetime").Count() != 0)
                {
                    var LastExecElemenct = getLastExecutionTimeNode.Where(x => x.Name.LocalName.ToLower() == "lastexecutiondatetime").FirstOrDefault();
                    LastExecElemenct.Value = DateTime.UtcNow.ToString("s");
                }
                else
                {
                    //create the child node
                    var variableElement = document.Element("Config").Element("Variables");
                    variableElement.Add(new XElement("LastExecutionDateTime", DateTime.UtcNow.ToString("s")));
                }
            }
            else
            //create the variable
            {
                XElement root = new XElement("Variables");
                root.Add(new XElement("LastExecutionDateTime", DateTime.UtcNow.ToString("s")));
                document.Element("Config").Add(root);
            }
            try
            {
                document.Save(docPath);
            }
            catch (Exception ex)
            {
                _defaultLogger.Error(ex);
            }
        }
        #endregion
    }
}
