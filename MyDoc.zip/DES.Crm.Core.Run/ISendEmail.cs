﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;

namespace DES.Crm.Core.Run
{
    public class EmailAttachment
    {
        public byte[] Bytes { get; set; }
        public string FileName { get; set; }
        public string MimeType { get; set; }

    }

    public class SendEmailArgs
    {
        public string To { get; set; }
        public string From  { get; set; }
        public string CC { get; set; }
        public string BCC { get; set; }
        public string Subject { get; set; }
        public string Body { get; set; }

        public List<EmailAttachment> EmailAttachments { get; set; }
    }

    public interface ISendEmail
    {
        SmtpStatusCode SendEmail(SendEmailArgs args);
    }

}
