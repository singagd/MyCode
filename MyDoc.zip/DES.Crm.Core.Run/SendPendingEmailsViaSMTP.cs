﻿using log4net.Core;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Client;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

//https://msdn.microsoft.com/en-us/library/mt608007.aspx
//https://technet.microsoft.com/en-us/library/dn531157.aspx#Email entity
//https://msdn.microsoft.com/en-us/library/office/dd633626(v=exchg.80).aspx
//SendPendingEmailsViaSMTP
//Fetch emails where 
//( state = 0 (Open) and status = 8 (Failed) )
// or 
//( state = 1 (Completed) and status = 6 (Pending Send) )

//For each email retrieve the following attributes
//Retrieve email attributes: activityid, attachmentcount, category, compressed, delayedemailsendtime, deliveryattempts, deliverylastattemptedon, description, exchangeitemid, exchangeweblink, mimetype, readreceiptrequested, sender, statecode, statuscode, subcategory, subject, torecipients
//Apply requried logic (i.e: do not send if delayedemailsendtime < now, update deliveryattempts = deliveryattempts + 1, update exchangeitemid)
//Send the email via SMTP server
//On success Update status = 1 (Completed) and status  = 3 (Sent)
//On failure Update status = 0 (Completed) and status  = 8 (Failed)

namespace DES.Crm.Core.Run
{
    public class SendPendingEmailsViaSMTP
    {
        public enum ContactAcknowledgementStatus
        {
            NotRequired = 859770001,
            Required = 859770002,
            NotDelivered = 859770003,
            PendingSend = 859770004,
            Sent = 859770000
        }

        public enum EmailActivitiyStateCode
        {
            Open = 0,
            Completed = 1,
            Canceled = 2
        }

        public enum EmailActivityStatusCode
        {
            /// <summary>
            /// Use with EmailActivitiyStateCode.Open
            /// </summary>
            Draft = 1,
            /// <summary>
            /// Use with EmailActivitiyStateCode.Completed
            /// </summary>
            Completed = 2,
            /// <summary>
            /// Use with EmailActivitiyStateCode.Completed
            /// </summary>
            Sent = 3,
            /// <summary>
            /// Use with EmailActivitiyStateCode.Completed
            /// </summary>
            Received = 4,
            /// <summary>
            /// Use with EmailActivitiyStateCode.Canceled
            /// </summary>
            Canceled = 5,
            /// <summary>
            /// Use with EmailActivitiyStateCode.Completed
            /// </summary>
            PendingSend = 6,
            /// <summary>
            /// Use with EmailActivitiyStateCode.Completed
            /// </summary>
            Sending = 7,
            /// <summary>
            /// Use with EmailActivitiyStateCode.Open
            /// </summary>
            Failed = 8
        }

        const string ACKNOWLEDGEMENT_STRING = "Acknowledgement Email";
        const string USESUBCATEGORY_ELEMENTNAME = "UseSubCategory";

        XDocument _ConfigFile;

        IOrganizationService _Service;
        ISendEmail _Emailer;
        ILog _Logger;
        IRetrieveSendEmailArgs<Entity> _RetrieveEmailArgs;

        public SendPendingEmailsViaSMTP(
            IOrganizationService service, 
            ISendEmail emailer, 
            ILog logger,
            IRetrieveSendEmailArgs<Entity> retrieveArgs,
            XDocument configXml)
        {
            _Service = service;
            _Emailer = emailer;
            _Logger = logger;
            _RetrieveEmailArgs = retrieveArgs;
            _ConfigFile = configXml;
        }

        public void Run()
        {
            var emailsToSend = RetrieveEmailsToSend();

            if (emailsToSend != null && emailsToSend.Count > 0)
            {
                foreach (var email in emailsToSend)
                {
                    SendAndUpdateEmail(email);
                }
            }
        }

        private List<Entity> RetrieveEmailsToSend(int count = 100)
        {
            try
            {
                _Logger.Info("Retrieving pending emails ready to be sent ... ");
                QueryExpression query = new QueryExpression();
                query.Criteria.AddCondition(new ConditionExpression("statecode", ConditionOperator.Equal, 1));
                query.Criteria.AddCondition(new ConditionExpression("statuscode", ConditionOperator.Equal, 6));

                if (UseSubCategoryCondition())
                {
                    query.Criteria.AddCondition(new ConditionExpression("subcategory", ConditionOperator.NotNull));
                }
                
                query.ColumnSet = new ColumnSet(true);
                query.EntityName = "email";

                var entityCollection = _Service.RetrieveMultiple(query);

                _Logger.Info("Retrieved {0} emails to ready to be sent.", entityCollection?.Entities.Count);

                return entityCollection?.Entities.ToList();
            }
            catch (Exception exc)
            {
                _Logger.Error(exc);
            }

            return null;
        }

        private bool UseSubCategoryCondition()
        {
            string returnString = string.Empty;

            if (_ConfigFile != null)
            {
                var getNode = _ConfigFile.Element("Config")
                                   .Element("Run")
                                   .Element("SendPendingEmailsViaSMTP")
                                   .Elements()
                                   .Where(x => x.Name == USESUBCATEGORY_ELEMENTNAME)
                                   .FirstOrDefault();

                if (getNode != null && !string.IsNullOrEmpty(getNode.Value))
                    return getNode.Value.ToLower().Trim() == "true";

                return false;
            }
            else
            {
                throw new Exception("Config file is null!");
            }
        }

        private void SendAndUpdateEmail(Entity emailEntity)
        {
            try
            {
                // Get the send email args
                var emailArgs = _RetrieveEmailArgs.GetArgs(emailEntity);
                var emailSentCode = _Emailer.SendEmail(emailArgs);

                var successfulMessage = emailSentCode == System.Net.Mail.SmtpStatusCode.Ok;

                var emailActivityStateCode = successfulMessage ? EmailActivitiyStateCode.Completed : EmailActivitiyStateCode.Open;
                var emailActivityStatusCode = successfulMessage ? EmailActivityStatusCode.Sent : EmailActivityStatusCode.Failed;
                var contactAcknowledgementStatus = successfulMessage ?  ContactAcknowledgementStatus.Sent : ContactAcknowledgementStatus.NotDelivered;

                UpdateEmailActivity(emailEntity, emailActivityStatusCode, emailActivityStateCode);
            }
            catch (Exception exc)
            {
                _Logger.Error(exc);
            }

        }
  
        /// <summary>
        /// Update the email activity with the required statecode and statusreason
        /// </summary>
        /// <param name="emailEntity">The email Activity to focus on</param>
        /// <param name="stateCode">The stateCode Open, Completed, Cancelled</param>
        /// <param name="statusReason">The status Reason</param>
        private void UpdateEmailActivity(Entity emailEntity, EmailActivityStatusCode statusReason, EmailActivitiyStateCode stateCode )
        {
            // Make it active
            var makeActiveRequest = new SetStateRequest();
            var activityId = emailEntity.Id;
            makeActiveRequest.EntityMoniker = new EntityReference("email", activityId);
            makeActiveRequest.State = new OptionSetValue((int)EmailActivitiyStateCode.Open);
            makeActiveRequest.Status = new OptionSetValue((int)EmailActivityStatusCode.Draft);

            _Logger.Info(string.Format("Making the email activity with id '{0}' Active.", activityId));

            var responseToMakeActive = (SetStateResponse)_Service.Execute(makeActiveRequest);

            var emailActivity = _Service.Retrieve("email", activityId, new Microsoft.Xrm.Sdk.Query.ColumnSet(true));

            // Set the required state
            var changeStatusRequest = new SetStateRequest();
            changeStatusRequest.EntityMoniker = new EntityReference("email", activityId);
            changeStatusRequest.State = new OptionSetValue((int)stateCode);
            changeStatusRequest.Status = new OptionSetValue((int)statusReason);

            _Logger.Info(string.Format("Updating the email activity with id '{0}' State {1} and Status {2}.", activityId, stateCode, statusReason));

            var responseToStateChange = (SetStateResponse)_Service.Execute(changeStatusRequest);
            
        }
    }
}
