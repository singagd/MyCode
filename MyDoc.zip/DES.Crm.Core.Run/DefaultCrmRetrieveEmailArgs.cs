﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace DES.Crm.Core.Run
{
    public class DefaultCrmRetrieveEmailArgs : IRetrieveSendEmailArgs<Entity>
    {
        private const string CONTACT_EMAIL_ATTRIB = "ContactEmailAttributeName";
        private const string QUEUE_EMAIL_ATTRIB = "QueueEmailAttributeName";
        private const string ACCOUNT_EMAIL_ATTRIB = "AccountEmailAttributeName";
        private const string SYSTEMUSER_EMAIL_ATTRIB = "SystemUserEmailAttributeName";      

        IOrganizationService _Service;
        ILog _Logger;
        XDocument _ConfigFile;
        bool _SendAttachments;
        public DefaultCrmRetrieveEmailArgs(IOrganizationService service, ILog logger, XDocument configFile, bool sendAttachments)
        {
            _Service = service;
            _Logger = logger;
            _ConfigFile = configFile;
            _SendAttachments = sendAttachments;
        }

        /// <summary>
        /// Retrieve the object of arguments from the email activity 
        /// 
        /// </summary>
        /// <param name="emailEntity"></param>
        /// <returns></returns>
        public SendEmailArgs GetArgs(Entity emailEntity)
        {
            SendEmailArgs returnArgs = null;

            if (emailEntity != null)
            {
                string name = emailEntity.GetAttributeValue<string>("name");

                _Logger.Info(string.Format("Retrieving email args for email entity '{0}', ID '{1}'.", name, emailEntity.Id));

                var fromParty = emailEntity.GetAttributeValue<EntityCollection>("from");
                var toParty = emailEntity.GetAttributeValue<EntityCollection>("to");
                var ccParty = emailEntity.Contains("cc") && emailEntity.GetAttributeValue<EntityCollection>("cc").Entities!=null 
                                && emailEntity.GetAttributeValue<EntityCollection>("cc").Entities.Count>0? emailEntity.GetAttributeValue<EntityCollection>("cc"):null;
                var bccParty = emailEntity.Contains("bcc")&& emailEntity.GetAttributeValue<EntityCollection>("bcc").Entities != null &&
                                emailEntity.GetAttributeValue<EntityCollection>("bcc").Entities.Count > 0 ? emailEntity.GetAttributeValue<EntityCollection>("bcc") : null;
                var fromEmails = GetEmailsFromEntityCollection(fromParty);
                var toEmails = GetEmailsFromEntityCollection(toParty);
                List<String> ccEmails = new List<string>();
                List<String> bccEmails = new List<string>();
                //adding a try catch as the calling method throws ex in case of anything invalid, but cc and bcc are optional values
                try
                {
                    if (ccParty != null)
                        ccEmails = GetEmailsFromEntityCollection(ccParty);
                    if (bccParty != null)
                        bccEmails = GetEmailsFromEntityCollection(bccParty);
                }
                catch (Exception ex)
                {
                    _Logger.Error(ex);
                }

                // fill the return args
                returnArgs = new SendEmailArgs();
                returnArgs.To = string.Join(",", toEmails.ToArray());
                returnArgs.From = fromEmails[0]; // there should only be one from address
                returnArgs.Subject = GetSubjectFromEmailEntity(emailEntity);
                returnArgs.Body = GetBodyFromEmailEntity(emailEntity);
                if (ccEmails != null && ccEmails.Count > 0)
                    returnArgs.CC = string.Join(",", ccEmails.ToArray());
                if (bccEmails != null && bccEmails.Count > 0)
                    returnArgs.BCC = string.Join(",", bccEmails.ToArray());         
                if (_SendAttachments)
                    returnArgs.EmailAttachments = RetrieveAttachments(emailEntity);
            }

            return returnArgs;
        }
        public List<EmailAttachment> RetrieveAttachments(Entity emailEntity)
        {
            List<EmailAttachment> _lstAttachments = new List<EmailAttachment>();
            QueryExpression attachmentquery = new QueryExpression("activitymimeattachment");
            attachmentquery.NoLock = true;
            attachmentquery.ColumnSet = new ColumnSet("body", "filename","mimetype");
            attachmentquery.Criteria.AddCondition(new ConditionExpression("objectid", ConditionOperator.Equal, emailEntity.Id));
            EntityCollection AttachmentCollection = _Service.RetrieveMultiple(attachmentquery);
            foreach (var item in AttachmentCollection.Entities)
            {
                EmailAttachment _attachments = new EmailAttachment();
                string body = item.Contains("body") ? item.GetAttributeValue<string>("body") : string.Empty;
                _attachments.Bytes = Convert.FromBase64String(body);
                _attachments.FileName = item.Contains("filename") ?item.GetAttributeValue<string>("filename"):string.Empty;
                _attachments.MimeType = item.Contains("mimetype") ? item.GetAttributeValue<string>("mimetype") : string.Empty;
                _lstAttachments.Add(_attachments);
            }
            return _lstAttachments;

        }

        private string GetBodyFromEmailEntity(Entity emailEntity)
        {
            return emailEntity.GetAttributeValue<string>("description");
        }

        private string GetSubjectFromEmailEntity(Entity emailEntity)
        {
            return emailEntity.GetAttributeValue<string>("subject");
        }

        private List<string> GetEmailsFromEntityCollection(EntityCollection collection)
        {
            var returnEmail = new List<string>();

            if (collection != null && collection.Entities.Count > 0)
            {
                foreach (var entity in collection.Entities)
                {
                    var emailToAdd = string.Empty;
                    var entityRef = entity.GetAttributeValue<EntityReference>("partyid");
                    var entityId = entityRef.Id;
                    switch (entityRef.LogicalName)
                    {
                        case "contact":
                            emailToAdd = GetEmailFromContact(entityId);
                            break;
                        case "account":
                            emailToAdd = GetEmailFromAccount(entityId);
                            break;
                        case "queue":
                            emailToAdd = GetEmailFromQueue(entityId);
                            break;
                        case "systemuser":
                            emailToAdd = GetEmailFromSystemUser(entityId);
                            break;
                        default:
                            throw new Exception(string.Format("Entity type '{0}' is not being handled to get email from CRM. You need to modify the source code to include this case. Please contact the product owner.", entity.LogicalName));
                    }

                    returnEmail.Add(emailToAdd);
                }
            }
            else {
                throw new Exception("There are no entities in this entity collection."); 
            }

            return returnEmail;
        }

        private string GetEmailFromContact(Guid contactId)
        {
            var emailColumn = RetrieveEmailAddressFromElementName(CONTACT_EMAIL_ATTRIB);
            var contact = _Service.Retrieve("contact", contactId, new Microsoft.Xrm.Sdk.Query.ColumnSet(emailColumn, "fullname"));
            if (contact != null && contact.Contains(emailColumn))
                return contact.GetAttributeValue<string>(emailColumn);

            throw new Exception(string.Format("SystemUser with id '{0}' doest not exist or is missing an email address in attribute '{1}': '{2}'.", contactId, emailColumn, contact.GetAttributeValue<string>("fullname")));
        }


        private string GetEmailFromQueue(Guid queueId)
        {
            var emailColumn = RetrieveEmailAddressFromElementName(QUEUE_EMAIL_ATTRIB);
            var queue = _Service.Retrieve("queue", queueId, new Microsoft.Xrm.Sdk.Query.ColumnSet(emailColumn, "name"));
            if (queue != null && queue.Contains("emailaddress"))
                return queue.GetAttributeValue<string>("emailaddress");

            throw new Exception(string.Format("SystemUser with id '{0}' doest not exist or is missing an email address in attribute '{1}': '{2}'.", queueId, emailColumn, queue.GetAttributeValue<string>("name")));
        }

        private string GetEmailFromAccount(Guid accountId)
        {
            var emailColumn = RetrieveEmailAddressFromElementName(ACCOUNT_EMAIL_ATTRIB);
            var account = _Service.Retrieve("account", accountId, new Microsoft.Xrm.Sdk.Query.ColumnSet(emailColumn, "name"));
            if (accountId != null && account.Contains(emailColumn))
                return account.GetAttributeValue<string>(emailColumn);

            throw new Exception(string.Format("SystemUser with id '{0}' doest not exist or is missing an email address in attribute '{1}': '{2}'.", accountId, emailColumn, account.GetAttributeValue<string>("name")));
        }

        private string GetEmailFromSystemUser(Guid systemuserId)
        {
            var emailColumn = RetrieveEmailAddressFromElementName(SYSTEMUSER_EMAIL_ATTRIB);
            var systemuser = _Service.Retrieve("systemuser", systemuserId, new Microsoft.Xrm.Sdk.Query.ColumnSet(emailColumn, "fullname"));
            if (systemuser != null && systemuser.Contains(emailColumn))
                return systemuser.GetAttributeValue<string>(emailColumn);

            throw new Exception(string.Format("SystemUser with id '{0}' doest not exist or is missing an email address in attribute '{1}': '{2}'.", systemuserId, emailColumn, systemuser.GetAttributeValue<string>("fullname")));
        }

        private string RetrieveEmailAddressFromElementName(string elementName)
        {
            string returnString = string.Empty;

            if (_ConfigFile != null)
            {
                var getNode = _ConfigFile.Element("Config")
                                   .Element("Run")
                                   .Element("SendPendingEmailsViaSMTP")
                                   .Elements()
                                   .Where(x => x.Name == elementName)
                                   .FirstOrDefault();

                if (getNode != null)
                    return getNode.Value;
                else
                    throw new Exception(string.Format("Cannot find the element '{0}' within the config.xml. Please make sure this is set on the config file.", elementName));

            }else
            {
                throw new Exception("Config file is null!. Please create the config.xml file");
            }
        }
    }
}
