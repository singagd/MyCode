﻿using log4net;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

[assembly: log4net.Config.XmlConfigurator(Watch = true)]
namespace DES.Crm.Core.Run
{
    public class DefaultLogger : ILog
    {
        private static log4net.ILog Log { get; set; }
        public DefaultLogger()
        {
            if (Log == null)
            {
                Log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
            }
        }

        public void Error(Exception exc)
        {
            Log.Error(string.Empty, exc);
            Console.WriteLine(DateTime.UtcNow.ToString("s") + ". " + exc.ToString());
        }

        public void Error(string error)
        {
            Log.Error(error);
            Console.WriteLine(DateTime.UtcNow.ToString("s") + ". " + error);
        }

        public void Info(string message)
        {
            Log.Info(message);
            Console.WriteLine(DateTime.UtcNow.ToString("s") + ". " + message);
        }

        public void Info(string message, params object[] args)
        {
            Log.Info(string.Format(message, args));
            Console.WriteLine(DateTime.UtcNow.ToString("s") + ". " + message + ". " + args.ToString());
        }
    }
}
