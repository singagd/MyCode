﻿namespace DES.Crm.Core.AppInsightsLogger
{
    public enum AiExceptionSeverity
    {
        Verbose,
        Information,
        Warning,
        Error,
        Critical
    }
}