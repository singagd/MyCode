﻿namespace DES.Crm.Core.AppInsightsLogger
{
    public enum AiLogType
    {
        Trace,
        Event,
        NetException,
        JsException,
        PerfMetric
    }
}