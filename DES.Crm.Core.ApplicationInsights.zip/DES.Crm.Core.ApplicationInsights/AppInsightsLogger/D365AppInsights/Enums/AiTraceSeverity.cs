﻿namespace DES.Crm.Core.AppInsightsLogger
{
    public enum AiTraceSeverity
    {
        Verbose,
        Information,
        Warning,
        Error,
        Critical
    }
}