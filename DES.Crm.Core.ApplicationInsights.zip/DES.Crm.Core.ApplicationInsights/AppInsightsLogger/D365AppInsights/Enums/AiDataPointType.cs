﻿namespace DES.Crm.Core.AppInsightsLogger
{
    public enum AiDataPointType
    {
        Measurement = 0,
        Aggregation = 1
    }
}