using System.Runtime.Serialization;

namespace DES.Crm.Core.AppInsightsLogger
{
    [DataContract]
    public class AiData
    {
        [DataMember(Name = "baseType")]
        public string BaseType { get; set; }

        [DataMember(Name = "baseData")]
        public AiBaseData BaseData { get; set; }
    }
}