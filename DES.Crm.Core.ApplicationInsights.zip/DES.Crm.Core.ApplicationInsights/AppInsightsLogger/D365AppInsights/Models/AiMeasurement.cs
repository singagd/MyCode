﻿using System.Collections.Generic;
using System.Runtime.Serialization;

namespace DES.Crm.Core.AppInsightsLogger
{
    [DataContract]
    public class AiMeasurements
    {
        public Dictionary<string, double> Measurements { get; set; }
    }
}