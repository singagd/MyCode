﻿using System.Activities;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Messages;

public sealed class UpdateDataRetentionRecords : CodeActivity
{

    #region Properties


    #endregion

    #region Class Variables

    IWorkflowContext context;
    ITracingService trace;
    IOrganizationServiceFactory serviceFactory;
    IOrganizationService service;
    #endregion
    protected override void Execute(CodeActivityContext executionContext)
    {

        try
        {
            //Apply the required business logic
            //Gets entityName and entityId
            context = executionContext.GetExtension<IWorkflowContext>();
            trace = executionContext.GetExtension<ITracingService>();
            serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            service = serviceFactory.CreateOrganizationService(context.UserId);
            String entityName = context.PrimaryEntityName;
            Guid entityId = context.PrimaryEntityId;

            //Retrieve the updated values of fields in Data Retnention configuration
            Entity dataretentionconfiguration = service.Retrieve("rbs_dataretentionconfiguration", entityId, new ColumnSet(true));

            //RETRIEVES RECORDS FROM rbs_dataretentionrecods WHERE rbs_dataretentionrecordconfigurationid = entityId
            //and status reason of data retentionrecord is "In retention Period"
            //FOR EACH RECORD
            //REPLICATES LOGIC IN UpsertDataRetentionRecord TO UPDATE rbs_dataretentionrecord(s) EXCEP 
            //THAT DO NOT UPDATE 'Action on' rbs_dataretentionrecord.rbs_actionon > =rbs_dataretentionconfiguration.rbs_actionon 

            QueryExpression qeForRelatedDataRetentionRecords = new QueryExpression("rbs_dataretentionrecord");
            qeForRelatedDataRetentionRecords.Criteria.AddFilter(LogicalOperator.And);
            qeForRelatedDataRetentionRecords.Criteria.AddCondition("rbs_dataretentionconfigurationid", ConditionOperator.Equal, context.PrimaryEntityId);
            qeForRelatedDataRetentionRecords.Criteria.AddCondition(new ConditionExpression("statuscode", ConditionOperator.Equal, 1));
            qeForRelatedDataRetentionRecords.NoLock = true;
            EntityCollection dataRetentionRecordsAssociatedWithPolicy = service.RetrieveMultiple(qeForRelatedDataRetentionRecords);

            if (dataRetentionRecordsAssociatedWithPolicy != null && dataRetentionRecordsAssociatedWithPolicy.Entities != null && dataRetentionRecordsAssociatedWithPolicy.Entities.Count > 0)
            {
                ExecuteMultipleRequest requestForBulkUpdateDRRecords = new ExecuteMultipleRequest()
                {
                    // Assign settings that define execution behavior: continue on error, return responses. 
                    Settings = new ExecuteMultipleSettings()
                    {
                        ContinueOnError = true,
                        ReturnResponses = false
                    },
                    // Create an empty organization request collection.
                    Requests = new OrganizationRequestCollection()
                };

                EntityCollection toBeUpdatedDataRetentionRecordsAssociatedWithPolicy = CalculateValuesToBeUpdated(dataRetentionRecordsAssociatedWithPolicy, dataretentionconfiguration, service, context);
                trace.Trace("Total number of entities to be updated " + toBeUpdatedDataRetentionRecordsAssociatedWithPolicy.Entities.Count);

                foreach (var entity in toBeUpdatedDataRetentionRecordsAssociatedWithPolicy.Entities)
                {
                    UpdateRequest updateRequest = new UpdateRequest { Target = entity };
                    requestForBulkUpdateDRRecords.Requests.Add(updateRequest);
                }
                ExecuteMultipleResponse responseWithContinueOnError =
                        (ExecuteMultipleResponse)service.Execute(requestForBulkUpdateDRRecords);
                if (responseWithContinueOnError.Responses.Count > 0)
                {
                    if (responseWithContinueOnError.Responses.Count < requestForBulkUpdateDRRecords.Requests.Count)
                    {
                        trace.Trace("Response collection contain a mix of successful response objects and errors.");
                    }

                    foreach (var responseItem in responseWithContinueOnError.Responses)
                    {
                        if (responseItem.Fault != null)
                            trace.Trace(requestForBulkUpdateDRRecords.Requests[responseItem.RequestIndex].ToString(),
                                responseItem.RequestIndex, responseItem.Fault);
                    }
                }
                else
                {
                    // No errors means all transactions are successful.
                    trace.Trace("All related data retention records related to policy change for " + dataretentionconfiguration.GetAttributeValue<string>("rbs_entityname") + "have been updated successfully.");
                }

            }
            else { trace.Trace("Query Expression for related configuration records yielded no results "); }


        }
        catch (Exception e)
        {
            //Handle the exception

            trace.Trace("Exception Message: " + e.Message);
            trace.Trace("Inner Exception Message: " + e.InnerException);
            trace.Trace("Exception Stack Trace: " + e.StackTrace);
        }

    }
    private static EntityCollection CalculateValuesToBeUpdated(EntityCollection dataRetentionRecordsAssociatedWithPolicy, Entity configurationPolicy, IOrganizationService service, IWorkflowContext context)
    {

        int i = 0;
        bool actionOnDateNeedsToBeRecalculated = false;
        int? actionAfterX = 0;
        string actionAfterPeriodType = "";
        bool needsToBeUpdated = false;
        DateTime actionOn;
        EntityCollection retentionCollection = new EntityCollection() { EntityName = "rbs_dataretentionrecord" };

        if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity)
        {
            Entity configurationEntityInContext = (Entity)context.InputParameters["Target"];


            foreach (Entity ent in dataRetentionRecordsAssociatedWithPolicy.Entities)
            {
                Entity dataRetentionRecord = service.Retrieve("rbs_dataretentionrecord", dataRetentionRecordsAssociatedWithPolicy.Entities[i].Id, new ColumnSet("rbs_triggerdate", "rbs_actionon"));

                if (configurationEntityInContext.Attributes.Contains("rbs_actionafterx") && configurationEntityInContext.Attributes["rbs_actionafterx"] != null)
                {
                    actionAfterX = Convert.ToInt32(configurationEntityInContext.Attributes["rbs_actionafterx"]);

                    actionOnDateNeedsToBeRecalculated = true;
                }
                if (configurationEntityInContext.Attributes.Contains("rbs_actionafterperiod") && configurationEntityInContext.Attributes["rbs_actionafterperiod"] != null)
                {
                    actionOnDateNeedsToBeRecalculated = true;
                }
                if (configurationEntityInContext.Attributes.Contains("rbs_action") && configurationEntityInContext.Attributes["rbs_action"] != null)
                {
                    bool action = Convert.ToBoolean(configurationEntityInContext.Attributes["rbs_action"]);
                    dataRetentionRecord.Attributes["rbs_action"] = action;
                    needsToBeUpdated = true;
                }

                if (actionOnDateNeedsToBeRecalculated != false)
                {
                    if (dataRetentionRecord.GetAttributeValue<DateTime>("rbs_triggerdate") != null)
                    {
                        if (actionAfterX == 0)
                        {
                            actionAfterX = Convert.ToInt32(configurationPolicy.GetAttributeValue<int>("rbs_actionafterx"));
                        }
                        actionAfterPeriodType = configurationPolicy.FormattedValues["rbs_actionafterperiod"];

                        actionOn = CommonMethods.CalculateRetentionDate(dataRetentionRecord.GetAttributeValue<DateTime>("rbs_triggerdate"), actionAfterX, actionAfterPeriodType);

                        if (actionOn >= dataRetentionRecord.GetAttributeValue<DateTime>("rbs_actionon"))
                        {
                            dataRetentionRecord.Attributes["rbs_actionon"] = actionOn;

                            needsToBeUpdated = true;
                        }

                    }

                }

                //dataRetentionRecord.Attributes["rbs_dataretentionconfigurationid"] = new EntityReference("rbs_dataretentionconfiguration", context.PrimaryEntityId);

                if (configurationEntityInContext.Attributes.Contains("rbs_entityname") && configurationEntityInContext.Attributes["rbs_entityname"] != null)
                {
                    RetrieveEntityRequest retrieveEntityRequest = new RetrieveEntityRequest()
                    {
                        LogicalName = configurationEntityInContext.Attributes["rbs_entityname"].ToString(),
                        RetrieveAsIfPublished = false
                    };
                    RetrieveEntityResponse retrieveEntityResponse = (RetrieveEntityResponse)service.Execute(retrieveEntityRequest);
                    bool entityExists = retrieveEntityResponse.EntityMetadata.LogicalName != null ? true : false;
                    if (entityExists) { dataRetentionRecord.Attributes["rbs_entity"] = configurationEntityInContext.Attributes["rbs_entityname"].ToString(); }


                }
                //dataRetentionRecord.Attributes["rbs_triggerdate"] = triggerDate;          

                if (needsToBeUpdated == true)
                {
                    retentionCollection.Entities.Add(dataRetentionRecord);
                }
                actionOnDateNeedsToBeRecalculated = false;
                needsToBeUpdated = false;
                i++;

            }

        }
        return retentionCollection;
    }
}


