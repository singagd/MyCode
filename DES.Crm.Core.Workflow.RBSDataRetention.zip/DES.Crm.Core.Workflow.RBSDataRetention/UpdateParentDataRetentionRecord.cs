﻿using System.Activities;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.ServiceModel;
using System.Collections.Generic;
using Microsoft.Xrm.Sdk.Query;
using System.Linq;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Metadata;



public sealed class UpdateParentDataRetentionRecord : CodeActivity
{

    #region Properties     

    [Input("Parent Entity Reference")]
    public InArgument<string> ParentEntityReference { get; set; }
 
    [Input("Override Status (numeric value of OptionSet)")]
    public InArgument<int> Status { get; set; }
    [Input("Override Action On Date")]
    public InArgument<DateTime> ActionOnDate { get; set; }

    [Input("Override Trigger On Date")]
    public InArgument<DateTime> TriggerOnDate { get; set; }


    #endregion

    #region Class Variables
    DateTime overRideActionOn = DateTime.MinValue;
    DateTime overRideTriggerOn = DateTime.MinValue;
    int overRideStatusCode = 0;

    IWorkflowContext context;
    ITracingService trace;
    IOrganizationServiceFactory serviceFactory;
    IOrganizationService service;
    #endregion

    protected override void Execute(CodeActivityContext executioncontext)
    {
        context = executioncontext.GetExtension<IWorkflowContext>();
        trace = executioncontext.GetExtension<ITracingService>();
        serviceFactory = executioncontext.GetExtension<IOrganizationServiceFactory>();
        service = serviceFactory.CreateOrganizationService(context.UserId);

       
        //RETRIEVES THE GUID OF THE LookUpAttributeName QUERYING THE REFERENCED ENTITY INTO ParentLookUpAttributeNameGuid
        //IF NOTHING RETRIEVED THEN LOG AND STOP

        //RETRIEVES rbs_dataretentionrecord where rbs_entity = ParentEntityLogicalName 
        //AND rbs_guid = ParentLookUpAttributeNameGuid INTO ParentDataRetentionRecord
        //IF NOTHING RETRIEVED THEN LOG AND STOP                            

        try
        {

            if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity)
            {
                overRideActionOn = executioncontext.GetValue<DateTime>(ActionOnDate);

                overRideTriggerOn = executioncontext.GetValue<DateTime>(TriggerOnDate);

                overRideStatusCode = executioncontext.GetValue<int>(Status);

                Entity TargetRecord = (Entity)context.InputParameters["Target"];

                trace.Trace("TARGET RECORD LOGICAL NAME " + TargetRecord.LogicalName.ToString());

                if (TargetRecord.LogicalName == "rbs_dataretentionrecord")
                {
                    TargetRecord = service.Retrieve(context.PrimaryEntityName, context.PrimaryEntityId, new ColumnSet("rbs_entity", "rbs_guid", "rbs_actionon", "statuscode", "rbs_dataretentionconfigurationid", "rbs_triggerdate"));

                    DateTime childActionOnDate = TargetRecord.Contains("rbs_actionon") ? TargetRecord.GetAttributeValue<DateTime>("rbs_actionon") : default(DateTime);

                    DateTime childTriggerOnDate = TargetRecord.Contains("rbs_triggerdate") ? TargetRecord.GetAttributeValue<DateTime>("rbs_triggerdate") : default(DateTime);

                    string childEntityName = TargetRecord.Contains("rbs_entity") ? TargetRecord.GetAttributeValue<string>("rbs_entity") : default(string);

                    int childStatus = TargetRecord.Contains("statuscode") ? (int)TargetRecord.GetAttributeValue<OptionSetValue>("statuscode").Value : default(int);

                    string childGuid = TargetRecord.Contains("rbs_guid") ? TargetRecord.GetAttributeValue<string>("rbs_guid") : default(string);

                    Guid dataRetentionConfigurationId = TargetRecord.Contains("rbs_dataretentionconfigurationid") ? TargetRecord.GetAttributeValue<EntityReference>("rbs_dataretentionconfigurationid").Id : Guid.Empty;

                    if (childActionOnDate != DateTime.MinValue && childStatus != 0 && childEntityName != string.Empty && childGuid != default(string) && dataRetentionConfigurationId != Guid.Empty)
                    {

                        //RETRIEVES THE EntityLogicalName OF THE LookUpAttributeName of the ParentRecord (QUERYING ATTRIBUTE METADATA OBJECT) INTO ParentEntityLogicalName (for instance: contact)
                        //IF NOTHING RETRIEVED THEN LOG AND STOP
                        QueryExpression qeRetriveParentAttribute = new QueryExpression("rbs_dataretentionparentattribute");

                        qeRetriveParentAttribute.ColumnSet.AddColumn("rbs_parentattributename");

                        qeRetriveParentAttribute.Criteria.AddCondition(new ConditionExpression("rbs_dataretentionconfiguration", ConditionOperator.Equal, dataRetentionConfigurationId));

                        qeRetriveParentAttribute.NoLock = true;

                        EntityCollection parentAttributeRecords = service.RetrieveMultiple(qeRetriveParentAttribute);

                        if (parentAttributeRecords != null && parentAttributeRecords.Entities != null && parentAttributeRecords.Entities.Count > 0)
                        {
                            //string[] parentAttributeValues = new string[] { };
                            List<string> parentAttributeValues = new List<string>();

                            int recordsUpdated = 0;

                            int index = 0;

                            foreach (var item in parentAttributeRecords.Entities)
                            {
                                var parentAttribute = item.GetAttributeValue<string>("rbs_parentattributename");

                                bool attributeExists = CommonMethods.ifAttributeExists(parentAttribute, childEntityName, service);

                                if (attributeExists)
                                {

                                    string primaryKeyAttribute, primaryField;

                                    CommonMethods.GetPrimaryAttributes(service, childEntityName, out primaryKeyAttribute, out primaryField);

                                    if (primaryKeyAttribute != null)
                                    {
                                        QueryExpression qeForParentattributesValue = new QueryExpression(childEntityName);

                                        qeForParentattributesValue.ColumnSet.AddColumn(parentAttribute);

                                        qeForParentattributesValue.Criteria.AddCondition(new ConditionExpression(primaryKeyAttribute, ConditionOperator.Equal, Guid.Parse(childGuid)));

                                        qeForParentattributesValue.NoLock = true;

                                        trace.Trace("primary key attibute found is " + primaryKeyAttribute);

                                        EntityCollection entCollection = service.RetrieveMultiple(qeForParentattributesValue);

                                        if (entCollection != null && entCollection.Entities != null && entCollection.Entities.Count > 0)
                                        {

                                            foreach (var ent in entCollection.Entities)
                                            {
                                                if (ent.GetAttributeValue<EntityReference>(parentAttribute) != null)
                                                {
                                                    EntityReference parentRecordGuid = ent.GetAttributeValue<EntityReference>(parentAttribute);

                                                    trace.Trace("parent attribute: " + parentAttribute + "  for child: " + ent.Id.ToString());

                                                    parentAttributeValues.Add(parentRecordGuid.Id.ToString());

                                                    index++;

                                                }
                                                else { trace.Trace("parent attribute: " + parentAttribute + " is null for child: " + ent.Id.ToString()); }


                                            }

                                        }
                                        else { trace.Trace("qeForParentattributesValue didn't yield any results"); }


                                    }
                                    else
                                    {
                                        throw new Exception("Couldn't find primary Key attribute for " + childEntityName);
                                    }
                                }
                                else { trace.Trace("Attribute " + parentAttribute + " doesn't exist for " + childEntityName); }

                            }
                            recordsUpdated = updateParentDrRecordsIfRequired(service, parentAttributeValues.ToArray(), childActionOnDate, childTriggerOnDate, childStatus);

                            if (recordsUpdated == parentAttributeValues.ToArray().Length)

                            { trace.Trace("All related parent records updated"); }
                            else
                            { trace.Trace("Not all related parent records were required for update"); }
                        }
                        else
                        {
                            trace.Trace("qeRetriveParentAttribute didn't yield any results");
                        }
                    }
                    else
                    {
                        throw new Exception("Workflow can not execute further, Either of these attributes do not have a valid value {parentActionOnDate, parentStatus, parentEntityName, parentEntityName, dataRetentionConfigurationId}");
                    }
                }
                else
                {
                    trace.Trace("=== Any Entity other than Data Retention Entity =");
                    //=======================================
                    //  Update Multiple Parents CONDITIONALLY
                    //=======================================
                    string primaryKeyAttribute, primaryField;
                  //  int parentStatusCode = 0;
                    string inputString = string.Empty;
                    int recordsUpdated = 0;
                   // DateTime actionOn = DateTime.MinValue;

                    
                    TargetRecord = (Entity)context.InputParameters["Target"];
                  
                    trace.Trace("Entity " + TargetRecord.LogicalName.ToString());                    

                    Guid primaryEntityId = context.PrimaryEntityId;
                    string primaryEntity = context.PrimaryEntityName;
                    
                    trace.Trace("Primary Entity Id " + primaryEntityId.ToString());
                    trace.Trace("Primary Entity  " + primaryEntity.ToString());
                    //============================================================================ 
                    //  Get the Primary Key attribute
                    //============================================================================ 
                    CommonMethods.GetPrimaryAttributes(service, primaryEntity, out primaryKeyAttribute, out primaryField);

                    trace.Trace("Primary Key Attribute   " + primaryKeyAttribute);
                    trace.Trace("Primary Field     " + primaryField);
                    //============================================================================ 
                    //  Retrieve the Parent Id for the Incoming Entity  
                    //============================================================================ 
                    
                    overRideActionOn = executioncontext.GetValue<DateTime>(ActionOnDate);
                    overRideStatusCode = executioncontext.GetValue<int>(Status);
                    overRideTriggerOn = executioncontext.GetValue<DateTime>(TriggerOnDate);

                    trace.Trace("Status Code after assignment " + overRideStatusCode.ToString());

                    if ((executioncontext != null) && (executioncontext.GetValue<string>(ParentEntityReference).ToString() != string.Empty))
                    {
                        inputString = executioncontext.GetValue<string>(ParentEntityReference);
                        trace.Trace("Incoming String   " + inputString);
                        if( inputString != string.Empty)
                        {
                            recordsUpdated = updateMultipleParentEntityRecords(service,inputString,primaryEntityId,primaryEntity,primaryKeyAttribute, overRideStatusCode, overRideActionOn, overRideTriggerOn);
                        }                        
                    }
                  }
                }
        }
        catch (Exception e)
        {
            trace.Trace("Exception Message: " + e.Message);
            trace.Trace("Inner Exception Message: " + e.InnerException);
            trace.Trace("Exception Stack Trace: " + e.StackTrace);
            throw e;
        }
    }

    //==================================================================================================================
    // We update multiple parents based on the Lookup Id and the Entity Name being passed from the ParentEntityReference
    // In case the Parent Action On Date is being passed, we  update the Parent DR with it
    // In case it is not being passed, we update it from the Child's record
    //=================================================================================================================
    private int updateMultipleParentEntityRecords(IOrganizationService service, string inputString,Guid primaryEntityId, string primaryEntity,string  primaryKeyAttribute, int parentStatusCode, DateTime actionOn, DateTime triggerOn)
    {
        int recordsUpdated = 0;

        string parentId = string.Empty;
        string parentEntityName = string.Empty;      
        DateTime actionOnChild = DateTime.MinValue;
        DateTime triggerOnDateChild  = DateTime.MinValue;
        //============================================================================ 
        // Declare the arrays for getting the incoming the Entity and Lookup attribute
        //============================================================================ 

        string[] entityArrayStrings = new string[] { };
        string[] attributeArrayStrings = new string[] { };

        entityArrayStrings = inputString.Split(',');

        if (entityArrayStrings.Length > 0)
            {
                foreach (string entityString in entityArrayStrings)
                {
                    // Check the incoming string.

                    if (entityString != String.Empty)
                    {

                        // Split to rbs_mortgageid & rbs_mortgage
                        trace.Trace("INCOMING STRING     " + entityString);
                        //check the Trim of the entity String
                        //Trim as required
                        attributeArrayStrings = entityString.Split('.');
                        parentId = attributeArrayStrings[0].Trim();
                        parentEntityName = attributeArrayStrings[1].Trim();

                        trace.Trace("Parent Id " + parentId.ToString());
                     

                        QueryExpression qeCurrentChildRecord = new QueryExpression(primaryEntity);
                        qeCurrentChildRecord.ColumnSet = new ColumnSet(parentId);
                        qeCurrentChildRecord.Criteria.AddFilter(LogicalOperator.And);
                        qeCurrentChildRecord.Criteria.AddCondition(new ConditionExpression(primaryKeyAttribute, ConditionOperator.Equal, primaryEntityId));
                        qeCurrentChildRecord.NoLock = true;

                        EntityCollection currentChildRecords = service.RetrieveMultiple(qeCurrentChildRecord);

                        if (currentChildRecords != null && currentChildRecords.Entities != null && currentChildRecords.Entities.Count > 0)
                        {
                            trace.Trace("Initial retrieve is good");
                            foreach (var currentChildRecord in currentChildRecords.Entities)// 
                            {
                                Guid parentGuid = currentChildRecord.Contains(parentId) ? currentChildRecord.GetAttributeValue<EntityReference>(parentId).Id : Guid.Empty;
                                trace.Trace("Parent Guid   " + parentGuid.ToString());
                                actionOnChild = DateTime.MinValue;
                                //===========================================================
                                 // Check the Incoming date and if it is null then asssign the Child's action on Date
                                 // Anyway do get the CHILD TRIGGER DATE as this is being not sent as a part of input paramerter
                                //=============================================================
                                
                                    QueryExpression qeChildDataRetentionRecord = new QueryExpression("rbs_dataretentionrecord");
                                    qeChildDataRetentionRecord.ColumnSet = new ColumnSet("rbs_actionon", "rbs_triggerdate");
                                    qeChildDataRetentionRecord.Criteria.AddCondition(new ConditionExpression("rbs_entity", ConditionOperator.Equal, primaryEntity));
                                    qeChildDataRetentionRecord.Criteria.AddCondition(new ConditionExpression("rbs_guid", ConditionOperator.Equal, primaryEntityId.ToString()));
                                    qeChildDataRetentionRecord.NoLock = true;

                                    EntityCollection drChildRecords = service.RetrieveMultiple(qeChildDataRetentionRecord);
                                    if (drChildRecords != null && drChildRecords.Entities != null && drChildRecords.Entities.Count > 0)
                                    {
                                        foreach (var drChildRecord in drChildRecords.Entities)
                                        {

                                                // Assign the Child's action on date only if the Parent is having the Action has Null
                                                if (actionOn == DateTime.MinValue)
                                                {
                                                    actionOnChild = drChildRecord.Attributes.Contains("rbs_actionon") ? drChildRecord.GetAttributeValue<DateTime>("rbs_actionon") : DateTime.MinValue;
                                                    if (actionOnChild != DateTime.MinValue) // Update the Action on Date only if both parent and Child do not have min value
                                                    {
                                                        actionOn = actionOnChild;

                                                    }
                                                }
                                                // GET THE CHILD Trigger date for sure
                                                if (triggerOn == DateTime.MinValue)
                                                {

                                                    triggerOnDateChild = drChildRecord.Attributes.Contains("rbs_triggerdate") ? drChildRecord.GetAttributeValue<DateTime>("rbs_triggerdate") : DateTime.MinValue;
                                                    triggerOn = triggerOnDateChild;
                                                }
                                            trace.Trace("Child action ON    " + actionOn.ToString());
                                            trace.Trace("Child Trigger ON    " + triggerOnDateChild.ToString());
                                        }
                                    }

                                
                                //====================================================================
                                //  Get the matching DR Record of the Parent from Data Retention Entity 
                                //======================================================================== 
                                QueryExpression qeParentDataRetentionRecord = new QueryExpression("rbs_dataretentionrecord");
                                qeParentDataRetentionRecord.Criteria.AddFilter(LogicalOperator.And);
                                qeParentDataRetentionRecord.Criteria.AddCondition(new ConditionExpression("rbs_entity", ConditionOperator.Equal, parentEntityName));
                                qeParentDataRetentionRecord.Criteria.AddCondition(new ConditionExpression("statuscode", ConditionOperator.In, new int[] { 1, 859770001 }));
                                qeParentDataRetentionRecord.Criteria.AddCondition(new ConditionExpression("rbs_guid", ConditionOperator.Equal, parentGuid.ToString()));
                                qeParentDataRetentionRecord.NoLock = true;


                                EntityCollection drParentRecords = service.RetrieveMultiple(qeParentDataRetentionRecord);
                                if (drParentRecords != null && drParentRecords.Entities != null && drParentRecords.Entities.Count > 0)
                                {
                                    foreach (var drParentRecord in drParentRecords.Entities)// 
                                    {
                                        trace.Trace("ACTION ON DATE " + actionOn.ToString());
                                        if (actionOn != DateTime.MinValue)
                                        {
                                            drParentRecord.Attributes["rbs_actionon"] = actionOn;
                                        }
                                        if(triggerOn != DateTime.MinValue)
                                        {

                                            drParentRecord.Attributes["rbs_triggerdate"] = triggerOn;
                                        }
                                        if (parentStatusCode > 0)
                                        {
                                            drParentRecord.Attributes["statuscode"] = new OptionSetValue(parentStatusCode);// in Retention Period: 1

                                            service.Update(drParentRecord);

                                            // Count of Records Updated.
                                            recordsUpdated++;

                                            trace.Trace("Update the DR Record  happened successfully");

                                            trace.Trace("Count of DR Records  have been updated successfully:" + recordsUpdated.ToString());
                                        }
                                        else
                                        {
                                            trace.Trace("Update the DR Record  did not happen ");
                                        }
                                    }
                                }
                            }

                        }
                    }

                }
            }       
            return recordsUpdated;
    }
    private int updateParentDrRecordsIfRequired(IOrganizationService service, string[] parentAttributeValues, DateTime childActionOnDate, DateTime childTriggerOnDate, int childStatus)
    {
        //Check If input parameter overRideActionOn has vlaue
        childActionOnDate = overRideActionOn != DateTime.MinValue ? overRideActionOn : childActionOnDate;

        //Check If input parameter overRideStatusCode has vlaue
        childStatus = overRideStatusCode != 0 ? overRideStatusCode : childStatus;

        //Check If input parameter overRideTriggerOn has vlaue
        childTriggerOnDate = overRideTriggerOn != DateTime.MinValue ? overRideTriggerOn : childTriggerOnDate;

        int recordsUpdated = 0;
        int i = 0;
        trace.Trace("length of parentAttribute array values is " + parentAttributeValues.Length);
        foreach (var record in parentAttributeValues)
        {
            QueryExpression qeForParentDataRetentionRecords = new QueryExpression("rbs_dataretentionrecord");

            qeForParentDataRetentionRecords.ColumnSet.AddColumns("rbs_actionon", "rbs_entity");

            qeForParentDataRetentionRecords.Criteria.AddCondition(new ConditionExpression("rbs_guid", ConditionOperator.Equal, parentAttributeValues[i]));

            qeForParentDataRetentionRecords.Criteria.AddCondition(new ConditionExpression("statuscode", ConditionOperator.In, new int[] { 1, 859770001 }));// In Retention Period or Not In Retention Period

            qeForParentDataRetentionRecords.NoLock = true;

            EntityCollection entCollection = service.RetrieveMultiple(qeForParentDataRetentionRecords);

            if (entCollection != null && entCollection.Entities != null && entCollection.Entities.Count > 0)
            {
                foreach (Entity ent in entCollection.Entities)
                {

                    if (ent.GetAttributeValue<DateTime>("rbs_actionon") != null)
                    {
                        //Update Only if any of the parent's values rbs_actionon,rbs_triggerdate,statuscode different from that of child
                        if (ent.Contains("rbs_actionon") && ent.GetAttributeValue<DateTime>("rbs_actionon") != childActionOnDate || ent.Contains("rbs_triggerdate") && ent.GetAttributeValue<DateTime>("rbs_triggerdate") != childTriggerOnDate || ent.Contains("statuscode") && ent.GetAttributeValue<OptionSetValue>("statuscode").Value != childStatus)
                        {
                            ent.Attributes["rbs_actionon"] = childActionOnDate;

                            ent.Attributes["rbs_triggerdate"] = childTriggerOnDate;

                            ent.Attributes["statuscode"] = new OptionSetValue(childStatus);

                            service.Update(ent);

                            recordsUpdated++;
                            //LOG
                            trace.Trace("Updated the data Retention record related to the parent " + ent.GetAttributeValue<string>("rbs_entity") + "with Id: " + ent.Id.ToString());
                        }
                        else
                        {
                            trace.Trace("Update avoided as all the values are same");
                        }
                    }
                    else { trace.Trace("Action on date is Null for parent with id " + ent.Id.ToString()); }
                }
            }
            else { trace.Trace("qeForCheckingParentEntityActionOn didn't yield any results"); }


            i++;
        }
        return recordsUpdated;
    }
}

