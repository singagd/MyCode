﻿
using System.Activities;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.ServiceModel;
using Microsoft.Xrm.Sdk.Query;


public sealed class DeleteDataRetentionRecord : CodeActivity
{

    #region Properties

    #endregion

    protected override void Execute(CodeActivityContext executionContext)
    {

        IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
        ITracingService trace = executionContext.GetExtension<ITracingService>();
        IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
        IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

        try
        {

            //DELETE CURRENT rbs_dataconfigurationrecod

            QueryExpression qeForDataRetentionRecord = new QueryExpression("rbs_dataretentionrecord");

            qeForDataRetentionRecord.Criteria.AddFilter(LogicalOperator.And);

            qeForDataRetentionRecord.Criteria.AddCondition(new ConditionExpression("rbs_entity", ConditionOperator.Equal, context.PrimaryEntityName));

            qeForDataRetentionRecord.Criteria.AddCondition(new ConditionExpression("rbs_guid", ConditionOperator.Equal, context.PrimaryEntityId.ToString()));

            qeForDataRetentionRecord.Criteria.AddCondition(new ConditionExpression("statuscode", ConditionOperator.Equal, 1));

            qeForDataRetentionRecord.NoLock = true;

            EntityCollection drRecord = service.RetrieveMultiple(qeForDataRetentionRecord);

            if (drRecord != null && drRecord.Entities != null && drRecord.Entities.Count > 0)
            {
                service.Delete("rbs_dataretentionrecord", drRecord.Entities[0].GetAttributeValue<Guid>("rbs_dataretentionrecordid"));

                trace.Trace("Deleted the data retention record earlier created for recordtype " + context.PrimaryEntityName + ", with id ='" + context.PrimaryEntityId);

            }
            else { trace.Trace("Query Expression didn't yield results"); }
        }
        catch (FaultException<OrganizationServiceFault> e)
        {
            //Handle the exception
            trace.Trace("Exception Message: " + e.Message);
            trace.Trace("Inner Exception Message: " + e.InnerException);
            trace.Trace("Exception Stack Trace: " + e.StackTrace);
            throw e;
        }

    }

}
