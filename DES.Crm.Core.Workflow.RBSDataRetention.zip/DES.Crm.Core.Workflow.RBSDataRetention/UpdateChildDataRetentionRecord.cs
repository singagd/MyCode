﻿using System.Activities;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.ServiceModel;
using System.Collections.Generic;
using Microsoft.Xrm.Sdk.Query;
using System.Linq;
using Microsoft.Xrm.Sdk.Messages;

public sealed class UpdateChildDataRetentionRecord : CodeActivity
{

    #region Properties
    [Input("Only Update Child If")]
    public InArgument<string> UpdateCondition { get; set; }
    [Input("Override Status (numeric value of OptionSet)")]
    public InArgument<int> Status { get; set; }
    [Input("Override Action On Date")]
    public InArgument<DateTime> ActionOnDate { get; set; }

    [Input("Override Trigger On Date")]
    public InArgument<DateTime> TriggerOnDate { get; set; }

    #endregion

    #region Class Variables
    DateTime overRideActionOn = DateTime.MinValue;
    DateTime overRideTriggerOn = DateTime.MinValue;
    int overRideStatusCode = 0;
    IWorkflowContext context;
    ITracingService trace;
    IOrganizationServiceFactory serviceFactory;
    IOrganizationService service;
    // string updateCondition;
    #endregion
    protected override void Execute(CodeActivityContext executioncontext)
    {

        context = executioncontext.GetExtension<IWorkflowContext>();
        trace = executioncontext.GetExtension<ITracingService>();
        serviceFactory = executioncontext.GetExtension<IOrganizationServiceFactory>();
        service = serviceFactory.CreateOrganizationService(context.UserId);

        //RETRIEVES THE GUID OF THE LookUpAttributeName QUERYING THE REFERENCED ENTITY INTO ParentLookUpAttributeNameGuid
        //IF NOTHING RETRIEVED THEN LOG AND STOP

        //RETRIEVES rbs_dataretentionrecord where rbs_entity = ParentEntityLogicalName 
        //AND rbs_guid = ParentLookUpAttributeNameGuid INTO ParentDataRetentionRecord
        //IF NOTHING RETRIEVED THEN LOG AND STOP                            

        try
        {
            if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity)
            {
                overRideActionOn = executioncontext.GetValue<DateTime>(ActionOnDate);

                overRideTriggerOn = executioncontext.GetValue<DateTime>(TriggerOnDate);

                overRideStatusCode = executioncontext.GetValue<int>(Status);

                Entity DRrecord = (Entity)context.InputParameters["Target"];

                if (DRrecord.LogicalName == "rbs_dataretentionrecord")
                {
                    DRrecord = service.Retrieve(context.PrimaryEntityName, context.PrimaryEntityId, new ColumnSet("rbs_entity", "rbs_guid", "rbs_actionon", "statuscode", "rbs_dataretentionconfigurationid","rbs_triggerdate"));

                    DateTime parentActionOnDate = DRrecord.Contains("rbs_actionon") ? DRrecord.GetAttributeValue<DateTime>("rbs_actionon") : default(DateTime);

                    DateTime parentTriggerOnDate = DRrecord.Contains("rbs_triggerdate") ? DRrecord.GetAttributeValue<DateTime>("rbs_triggerdate") : default(DateTime);

                    int parentStatus = DRrecord.Contains("statuscode") ? (int)DRrecord.GetAttributeValue<OptionSetValue>("statuscode").Value : default(int);

                    string parentEntityName = DRrecord.Contains("rbs_entity") ? DRrecord.GetAttributeValue<string>("rbs_entity") : default(string);

                    string parentGuid = DRrecord.Contains("rbs_guid") ? DRrecord.GetAttributeValue<string>("rbs_guid") : default(string);

                    Guid dataRetentionConfigurationId = DRrecord.Contains("rbs_dataretentionconfigurationid") ? DRrecord.GetAttributeValue<EntityReference>("rbs_dataretentionconfigurationid").Id : Guid.Empty;


                    if (parentActionOnDate != DateTime.MinValue && parentStatus != 0 && parentEntityName != string.Empty && parentGuid != default(string) && dataRetentionConfigurationId != Guid.Empty)
                    {
                        QueryExpression qeRetriveChildAttribute = new QueryExpression("rbs_dataretentionchildattribute");

                        qeRetriveChildAttribute.ColumnSet.AddColumn("rbs_childattribute");

                        qeRetriveChildAttribute.Criteria.AddCondition(new ConditionExpression("rbs_dataretentionconfiguration", ConditionOperator.Equal, dataRetentionConfigurationId));

                        qeRetriveChildAttribute.NoLock = true;

                        EntityCollection childAttributeRecords = service.RetrieveMultiple(qeRetriveChildAttribute);

                        if (childAttributeRecords != null && childAttributeRecords.Entities != null && childAttributeRecords.Entities.Count > 0)
                        {
                            //string[] parentAttributeValues = new string[] { };
                            List<string> parentAttributeValues = new List<string>();

                            int recordsUpdated = 0;

                            int index = 0;

                            foreach (var item in childAttributeRecords.Entities)
                            {
                                var relationShipAttribute = item.GetAttributeValue<string>("rbs_childattribute");

                                RetrieveRelationshipResponse relationShipResponse;

                                bool relationShipExists = CommonMethods.ifRelationShipExists(relationShipAttribute, service, out relationShipResponse);

                                if (relationShipExists)
                                {

                                    string primaryKeyAttribute, primaryField;


                                    // Instantiate QueryExpression QEactivitypointer

                                    QueryExpression QEchild = new QueryExpression(((Microsoft.Xrm.Sdk.Metadata.OneToManyRelationshipMetadata)relationShipResponse.RelationshipMetadata).ReferencingEntity);

                                    // Add link-entity QEactivitypointer_incident
                                    LinkEntity QEchild_Parent = QEchild.AddLink(((Microsoft.Xrm.Sdk.Metadata.OneToManyRelationshipMetadata)relationShipResponse.RelationshipMetadata).ReferencedEntity, ((Microsoft.Xrm.Sdk.Metadata.OneToManyRelationshipMetadata)relationShipResponse.RelationshipMetadata).ReferencingAttribute, ((Microsoft.Xrm.Sdk.Metadata.OneToManyRelationshipMetadata)relationShipResponse.RelationshipMetadata).ReferencedAttribute);

                                    // relationship.
                                    // Define filter QEactivitypointer_incident.LinkCriteria
                                    QEchild_Parent.LinkCriteria.AddCondition(((Microsoft.Xrm.Sdk.Metadata.OneToManyRelationshipMetadata)relationShipResponse.RelationshipMetadata).ReferencedAttribute, ConditionOperator.Equal, Guid.Parse(parentGuid));

                                    QEchild.NoLock = true;

                                    CommonMethods.GetPrimaryAttributes(service, ((Microsoft.Xrm.Sdk.Metadata.OneToManyRelationshipMetadata)relationShipResponse.RelationshipMetadata).ReferencingEntity, out primaryKeyAttribute, out primaryField);

                                    EntityCollection entCollection = service.RetrieveMultiple(QEchild);

                                    if (entCollection != null && entCollection.Entities != null && entCollection.Entities.Count > 0)
                                    {

                                        foreach (var ent in entCollection.Entities)
                                        {
                                            if (ent.GetAttributeValue<Guid>(primaryKeyAttribute) != null)
                                            {
                                                Guid childRecordRecordGuid = ent.GetAttributeValue<Guid>(primaryKeyAttribute);

                                                //trace.Trace("parent attribute: " + parentAttribute + "  for child: " + ent.Id.ToString());

                                                parentAttributeValues.Add(childRecordRecordGuid.ToString());

                                                index++;

                                            }
                                            else { trace.Trace("child record : " + primaryKeyAttribute + " is null: " + ent.Id.ToString()); }


                                        }

                                    }
                                    else { trace.Trace("QEchild couldn't yield any results"); }

                                }
                                else
                                {
                                    throw new Exception("Couldn't find the relationship" + relationShipAttribute);
                                }
                            }

                            recordsUpdated = updateChildDrRecordsIfRequired(service, parentAttributeValues.ToArray(), parentActionOnDate, parentTriggerOnDate, parentStatus, executioncontext.GetValue(UpdateCondition));

                            if (recordsUpdated == parentAttributeValues.ToArray().Length) { trace.Trace("All related parent records updated"); } else { trace.Trace("Not all related parent records were required for update"); }
                        }
                        else
                        {
                            trace.Trace("qeRetriveChildAttribute didn't yield any results");
                        }
                    }
                    else
                    {
                        throw new Exception("Workflow can not execute further, Either of these attributes do not have a valid value {parentActionOnDate, parentStatus, parentEntityName, parentEntityName, dataRetentionConfigurationId}");
                    }

                }

                else
                {
                    trace.Trace("This workflow is intended to trigger only for Data Retention Records");
                }



            }
            else
            {
                trace.Trace("Either the target is not present in input parameters or the target is not of entity type");
            }
        }


        catch (Exception e)
        {
            trace.Trace("Exception Message: " + e.Message);
            trace.Trace("Inner Exception Message: " + e.InnerException);
            trace.Trace("Exception Stack Trace: " + e.StackTrace);
            throw e;
        }
    }
    private int updateChildDrRecordsIfRequired(IOrganizationService service, string[] childAttributeValues, DateTime parentActionOnDate,DateTime parentTriggerOnDate, int parentStatus, string updateCondition)
    {
        int recordsUpdated = 0;

        int i = 0;
        //Check If input parameter overRideActionOn has vlaue
        parentActionOnDate = overRideActionOn != DateTime.MinValue ? overRideActionOn : parentActionOnDate;

        //Check If input parameter overRideStatusCode has vlaue
        parentStatus = overRideStatusCode != 0 ? overRideStatusCode : parentStatus;

        //Check If input parameter overRideTriggerOn has vlaue
        parentTriggerOnDate = overRideTriggerOn != DateTime.MinValue ? overRideTriggerOn : parentTriggerOnDate;

        trace.Trace("length of child atribute array values is " + childAttributeValues.Length);

        foreach (var record in childAttributeValues)
        {
            QueryExpression qeForChildDataRetentionRecords = new QueryExpression("rbs_dataretentionrecord");

            qeForChildDataRetentionRecords.ColumnSet.AddColumns("rbs_actionon", "rbs_entity");

            qeForChildDataRetentionRecords.Criteria.AddCondition(new ConditionExpression("rbs_guid", ConditionOperator.Equal, childAttributeValues[i]));

            qeForChildDataRetentionRecords.Criteria.AddCondition(new ConditionExpression("statuscode", ConditionOperator.In, new int[] { 1, 859770001 })); //In Retention Period or Not In Retention Period

            qeForChildDataRetentionRecords.NoLock = true;

            EntityCollection entCollection = service.RetrieveMultiple(qeForChildDataRetentionRecords);

            if (entCollection != null && entCollection.Entities != null && entCollection.Entities.Count > 0)
            {
                foreach (Entity ent in entCollection.Entities)
                {
                    if (ent.Contains("rbs_actionon") && ent.GetAttributeValue<DateTime>("rbs_actionon") != DateTime.MinValue)
                    {
                        if (!string.IsNullOrEmpty(updateCondition))
                        {
                            if (updateCondition.Trim().ToLower() == "parent greater")
                            {
                                if (ent.GetAttributeValue<DateTime>("rbs_actionon") <= parentActionOnDate)
                                {
                                    ent.Attributes["rbs_actionon"] = parentActionOnDate;

                                    ent.Attributes["rbs_triggerdate"] = parentTriggerOnDate;

                                    ent.Attributes["statuscode"] = new OptionSetValue(parentStatus);

                                    service.Update(ent);

                                    recordsUpdated++;
                                    //LOG
                                    trace.Trace("Updated the data Retention record related to the parent " + ent.GetAttributeValue<string>("rbs_entity") + "with Id: " + ent.Id.ToString());
                                }
                                else { trace.Trace("Can not update as Condition: " + updateCondition + " is not fulfilled"); }
                            }
                            else if (updateCondition.Trim().ToLower() == "child greater")
                            {
                                if (ent.GetAttributeValue<DateTime>("rbs_actionon") >= parentActionOnDate)
                                {

                                    ent.Attributes["rbs_actionon"] = parentActionOnDate;

                                    ent.Attributes["rbs_triggerdate"] = parentTriggerOnDate;

                                    ent.Attributes["statuscode"] = new OptionSetValue(parentStatus);

                                    service.Update(ent);

                                    recordsUpdated++;
                                    //LOG
                                    trace.Trace("Updated the data Retention record related to the parent " + ent.GetAttributeValue<string>("rbs_entity") + "with Id: " + ent.Id.ToString());
                                }
                                else { trace.Trace("Can not update as Condition: " + updateCondition + " is not fulfilled"); }
                            }
                            else
                            {
                                trace.Trace("Unhandled Condition");
                                throw new Exception("Unhandled Condition");
                            }
                        }
                        // if (ent.GetAttributeValue<DateTime>("rbs_actionon") <= parentActionOnDate)
                        //{
                        //UPDATES ParentDataRetentionRecord.rbs_actionon =  this.rbs_actionon 
                        else
                        {
                            if (ent.Contains("rbs_actionon") && ent.GetAttributeValue<DateTime>("rbs_actionon") != parentActionOnDate || ent.Contains("rbs_triggerdate") && ent.GetAttributeValue<DateTime>("rbs_triggerdate") != parentTriggerOnDate || ent.Contains("statuscode") && ent.GetAttributeValue<OptionSetValue>("statuscode").Value != parentStatus)
                            {
                                ent.Attributes["rbs_actionon"] = parentActionOnDate;

                                ent.Attributes["rbs_triggerdate"] = parentTriggerOnDate;

                                ent.Attributes["statuscode"] = new OptionSetValue(parentStatus);

                                service.Update(ent);

                                recordsUpdated++;
                                //LOG
                                trace.Trace("Updated the data Retention record related to the parent " + ent.GetAttributeValue<string>("rbs_entity") + "with Id: " + ent.Id.ToString());
                            }

                            else
                            {
                                trace.Trace("Update avoided as all the values are same");
                            }
                        }
                        }
                    else { trace.Trace("Action on date is default for parent with id " + ent.Id.ToString()); }
                }
            }
            else { trace.Trace("qeForChildActionDataRetentionRecords didn't yield any results"); }


            i++;
        }
        return recordsUpdated;
    }

}