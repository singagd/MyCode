﻿Data.fetchXML = {
    //Create fetchXML using received parameters which does not consist any link entity.
    fetchWithoutLinkedEntities : function (distinct, entityname, attributenames, filter, orderbydesc, orderattribute) {
        var query = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='" + distinct + "'> ";
        query = query + "<entity name='" + entityname + "'> ";

        if (typeof attributenames == "undefined" || attributenames.length == 0)
            query = query + "<all-attributes /> ";
        else {
            for (var i = 0; i < attributenames.length; i++)
                query = query + "<attribute name='" + title + "' />";
        };

        if (!((typeof orderbydesc == "undefined" || orderbydesc.length == 0) && (typeof orderattribute == "undefined" || orderattribute.length == 0)))
            query = query + "<order attribute='" + orderattribute + "' descending='" + orderbydesc + "' /> ";

        if (!((typeof filter == "undefined" || filter == null)))
        {
            for (var i = 0; i < filter.length; i++)
            {
                query = query + "<filter type ='"+filter[i].Filtertype+"' >";
                query = query + "<condition attribute = '" + filter[i].attribute + "' operator='" + filter[i].operator + "' value='" + filter[i].value + "' /></filter>";
            }
        }

        query = query + "</entity></fetch>";
    },

    //Create fetchXML using received parameters which consists non nested link entities.
    fetchWithDirectLinkedEntities : function (distinct, entityname, attributenames, filter, linkedentities, orderbydesc, orderattribute) {
        var query = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='" + distinct + "'> ";
        query = query + "<entity name='" + entityname + "'> ";

        if (typeof attributenames == "undefined" || attributenames.length == 0)
            query = query + "<all-attributes /> ";
        else {
            for (var i = 0; i < attributenames.length; i++)
                query = query + "<attribute name='" + title + "' /> ";
        };

        if (!((typeof filter == "undefined" || filter == null))) {
            for (var i = 0; i < filter.length; i++) {
                query = query + "<filter type ='" + filter[i].Filtertype + "' >";
                query = query + "<condition attribute = '" + filter[i].attribute + "' operator='" + filter[i].operator + "' value='" + filter[i].value + "' /></filter>";
            }
        }

        if (!(typeof linkedentities == "undefined" || linkedentities.length == 0))
            for (var j = 0; j < linkedentities.length; j++)
                query = query + "<link-entity name='" + linkedentities[j].name + "' from='" + linkedentities[j].from + "' to='" + linkedentities[j].to + "' >";

        if (!((typeof orderbydesc == "undefined" || orderbydesc.length == 0) && (typeof orderattribute == "undefined" || orderattribute.length == 0)))
            query = query + "<order attribute='" + orderattribute + "' descending='" + orderbydesc + "' /> ";

        query = query + "</entity></fetch>";
    }
}

Data.odata = {
    //Generates oData query dynamically on the basis of provided parameters.
    getRetrieveQueryPath: function (id, type, select, expand, filter) {

        var retrieveQuery = "";
        
        if (select != null)
            StringParameterCheck(select, "");
        if (expand != null)
            StringParameterCheck(expand, "");


        if (select != null || expand != null || filter != null) {
            systemQueryOptions = "?";
            if (select != null) {
                var selectString = "$select=" + select;
                systemQueryOptions = systemQueryOptions + selectString;
            }
            if (expand != null) {
                systemQueryOptions = systemQueryOptions + "&$expand=" + expand;
            }
            if (filter != null) {
                systemQueryOptions = systemQueryOptions + "&$filter=" + filter;
            }
        }

        return encodeURI(oDataPath() + type + "Set(guid'" + id + "')" + systemQueryOptions);
    },
}