﻿namespace DES.Crm.Core.Common.XRMLibrary.Auth
{
    using System.Net;

    public class AnonymousAuthenticationScheme : IAuthenticationScheme
    {        
        public void SignRequest(WebRequest request)
        {
        }
    }
}
