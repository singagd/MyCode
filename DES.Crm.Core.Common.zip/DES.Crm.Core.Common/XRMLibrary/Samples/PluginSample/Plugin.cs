﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DES.Crm.Core.Common.XRM.SDK;
using Microsoft.Xrm.Sdk;

namespace DES.Crm.Core.Common.XRMLibrary.Samples
{
    public class Plugin : PluginBase
    {
        protected override void ExecutePlugin(ICRMObjects crmObjects)
        {
            var context = crmObjects.PluginExecutionContext;
                       

            if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity)
            {
                Entity entity = (Entity)context.InputParameters["Target"];

                if (entity.LogicalName == "account")
                {
                    if (entity.Attributes.Contains("accountnumber") == false)
                    {
                        Random rndgen = new Random();
                        entity.Attributes.Add("accountnumber", rndgen.Next().ToString());
                    }
                    else
                    {
                        throw new InvalidPluginExecutionException("The account number can only be set by the system.");
                    }
                }
            }
		}		
    }
}
