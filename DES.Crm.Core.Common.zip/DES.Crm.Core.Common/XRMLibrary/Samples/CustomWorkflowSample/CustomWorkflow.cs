﻿using System;
using System.Activities;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DES.Crm.Core.Common.XRM.SDK;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Workflow;

namespace DES.Crm.Core.Common.XRMLibrary.Samples
{
    public class CustomWorkflow : WorkFlowActivityBase
    {
        protected override void ExecuteWorkflow(ICRMObjects crmObjects)
        {
            var accountName = this.AccountName.Get(crmObjects.executionContext);
            var accountDesc = this.AccountDescription.Get(crmObjects.executionContext);

            Library library = new XRM.SDK.Library(crmObjects.Service);            

            Entity account = new Entity("account");
            account["name"] = accountName;
            account["description"] = accountDesc;

            Guid accountIdentity = library.Create(account);

            AccountGuid.Set(crmObjects.executionContext, accountIdentity);
        }

        [Input("AccountName")]
        public InArgument<string> AccountName { get; set; }
        [Input("AccountDescription")]
        public InArgument<string> AccountDescription { get; set; }
        [Input("AccountGuid")]
        public OutArgument<Guid> AccountGuid { get; set; }
    }
}
