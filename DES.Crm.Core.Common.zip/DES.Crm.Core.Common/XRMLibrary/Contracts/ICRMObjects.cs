﻿using System;
using System.Activities;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Workflow;

namespace DES.Crm.Core.Common.XRM.SDK
{
    public interface ICRMObjects
    {
        IServiceProvider ServiceProvider { get; set; }
        IPluginExecutionContext PluginExecutionContext { get; set; }
        ITracingService TracingService { get; set; }
        IOrganizationServiceFactory factory { get; set; }
        IOrganizationService Service { get; set; }
        IWorkflowContext WorkflowExecutionContext { get; set; }
        CodeActivityContext executionContext { get; set; }        
    }
}
