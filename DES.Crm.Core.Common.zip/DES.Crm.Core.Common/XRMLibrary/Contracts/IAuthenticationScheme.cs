﻿namespace DES.Crm.Core.Common.XRMLibrary.Auth
{    
    using System.Net;

    public interface IAuthenticationScheme
    {
        void SignRequest(WebRequest request);
    }
}
