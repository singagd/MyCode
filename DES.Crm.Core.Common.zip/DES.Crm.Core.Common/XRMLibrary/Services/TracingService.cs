﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xrm.Sdk;

namespace DES.Crm.Core.Common.XRM.Wrappers
{
    public class TracingService
    {
        internal ITracingService tracingService { get; private set; }

        internal void Trace(IPluginExecutionContext context, string message)
            {
                if (string.IsNullOrWhiteSpace(message) || this.tracingService == null)
                {
                    return;
                }

                if (context == null)
                {
                    this.tracingService.Trace(message);
                }
                else
                {
                    this.tracingService.Trace("{0}, Correlation Id: {1}, Initiating User: {2}", message, context.CorrelationId, context.InitiatingUserId);
                }
            }
    }
}
