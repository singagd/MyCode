﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Query;

namespace DES.Crm.Core.Common.XRM.SDK
{
    public partial class Library
    {
        /// <summary>
        /// Retrieve Single record from CRM with all columns 
        /// </summary>
        /// <param name="EntityLogicalName"></param>
        /// <param name="ID"></param>
        /// <returns></returns>
        public Entity Retrieve(string EntityLogicalName, Guid ID)
        {
            try
            {
                Entity entity = service.Retrieve(EntityLogicalName, ID, new ColumnSet(true));
                return entity;
            }
            catch (Exception ex)
            {
                throw new Exception("Error while Retrieve records" + ex.Message);
            }
            finally
            {

            }
        }
        /// <summary>
        /// Retrieve Single record from CRM
        /// </summary>
        /// <param name="EntityLogicalName"></param>
        /// <param name="ID"></param>
        /// <param name="ColumnSet"></param>
        /// <returns></returns>
        public Entity Retrieve(string EntityLogicalName, Guid ID, string[] ColumnSet)
        {
            try
            {
                Entity entity = service.Retrieve(EntityLogicalName, ID, new ColumnSet(ColumnSet));
                return entity;
            }
            catch (Exception ex)
            {
                throw new Exception("Error while Retrieve records" + ex.Message);
            }
            finally
            {

            }            
        }

        /// <summary>
        /// Method used to retrieve records using Query by Attributes
        /// </summary>
        /// <param name="qba"></param>
        /// <returns></returns>
        public Collection<Entity> Retrieve(QueryByAttribute qba)
        {
            try
            {
                var requests = new RetrieveMultipleRequest();
                requests.Query = qba;
                return ((RetrieveMultipleResponse)service.Execute(requests)).EntityCollection.Entities;
            }
            catch (Exception ex)
            {
                throw new Exception("Error while Retrieve records" + ex.Message);
            }
            finally
            {

            }
        }

        /// <summary>
        /// Method used to retrieve bulk records 
        /// </summary>
        /// <param name="EntityLogicalName"></param>
        /// <param name="ColumnSet"></param>
        /// <param name="range"></param>
        /// <param name="value"></param>
        /// <returns></returns>
        public Collection<Entity> Retrieve(string EntityLogicalName, string[] ColumnSet, string range, string value)
        {
            try
            {
                var Query = new QueryByAttribute(EntityLogicalName);
                Query.ColumnSet = new Microsoft.Xrm.Sdk.Query.ColumnSet(ColumnSet);
                Query.Attributes.AddRange(range);
                Query.Values.AddRange(value);

                return Retrieve(Query);
                    
            }
            catch (Exception ex)
            {
                throw new Exception("Error while Retrieve records" + ex.Message);
            }
            finally
            {

            }
        }        

        /// <summary>
        /// Retrieve Multiple records from CRM based on conditions 
        /// </summary>
        /// <param name="EntityLogicalName"></param>
        /// <param name="ColumnSet"></param>
        /// <param name="Conditions"></param>
        /// <returns></returns>
        public EntityCollection RetrieveMultiple(string EntityLogicalName, string[] ColumnSet, List<Tuple<string, ConditionOperator, string>> Conditions)
        {
            try
            {
                //QueryExpression query1 = new QueryExpression
                //{
                //    EntityName = EntityLogicalName,
                //    ColumnSet = new ColumnSet(ColumnSet),
                //    Criteria = new FilterExpression
                //    {
                //        Conditions =
                //                {                            
                //                    new ConditionExpression
                //                    {
                //                        AttributeName = "name",
                //                        Operator = ConditionOperator.Equal,
                //                        Values = { "0" }
                //                    }                     
                //                }
                //    }
                //};

                QueryExpression query = new QueryExpression();
                query.EntityName = EntityLogicalName;
                query.ColumnSet = new Microsoft.Xrm.Sdk.Query.ColumnSet(ColumnSet);

                foreach(var condition in Conditions)
                {
                    query.Criteria.Conditions.Add(new ConditionExpression(condition.Item1.ToString(), condition.Item2, condition.Item3));
                }

                return service.RetrieveMultiple(query);

            }
            catch (Exception ex)
            {
                throw new Exception("Error while Retrieve records" + ex.Message);
            }
            finally
            {

            }
        }
    }
}
