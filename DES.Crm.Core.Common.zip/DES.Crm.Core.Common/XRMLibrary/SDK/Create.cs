﻿using System;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;

namespace DES.Crm.Core.Common.XRM.SDK
{
    //Create Request and Response
    /// <summary>
    /// Library methord is used to create the CRM entity
    /// </summary>
    public partial class Library
    {
        public Guid Create(Entity entity)
        {
            try
            { 
                var guid = service.Create(entity);
                return guid;
            }
            catch (Exception ex)
            {
                throw new Exception("Error while executing Create" + ex.Message);
            }
            finally
            {

            }            
        }

        //public void Create(Entity entity)
        //{
        //    try
        //    {
        //        var CreateRequest = new CreateRequest { Target = entity };
        //        service.Execute(CreateEequest);
        //    }
        //    catch (Exception ex)
        //    {
        //        throw new Exception("Error while executing Create" + ex.Message);
        //    }
        //    finally
        //    {

        //    }
        //}

        /// <summary>
        /// Create bulk entities in CRM
        /// </summary>
        /// <param name="objects"></param>
        /// <param name="SuppressDuplicateDetection"></param>
        /// <returns></returns>
        public ExecuteMultipleResponseItemCollection CreateMultiple(EntityCollection objects, bool SuppressDuplicateDetection)
        {
            ExecuteMultipleRequest requestWithResults;           
            try
            {               
                // Create an ExecuteMultipleRequest object.
                requestWithResults = new ExecuteMultipleRequest()
                {
                    // Assign settings that define execution behavior: continue on error, return responses. 
                    Settings = new ExecuteMultipleSettings()
                    {
                        ContinueOnError = false,
                        ReturnResponses = true
                    },

                    // Create an empty organization request collection.
                    Requests = new OrganizationRequestCollection()
                };


                // Add a CreateRequest for each entity to the request collection.
                foreach (var entity in objects.Entities)
                {
                    CreateRequest createRequest = new CreateRequest { Target = entity };
                    createRequest.Parameters.Add("SuppressDuplicateDetection", SuppressDuplicateDetection); // Change to true to deactivate the duplicate detection.
                    requestWithResults.Requests.Add(createRequest);
                }

                // Execute all the requests in the request collection using a single web method call.
                ExecuteMultipleResponse responseWithResults =
                    (ExecuteMultipleResponse)service.Execute(requestWithResults);

                return responseWithResults.Responses;                
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {

            }
        }
    }
}
