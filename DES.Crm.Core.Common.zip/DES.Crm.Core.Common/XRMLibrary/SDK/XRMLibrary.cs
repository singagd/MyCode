﻿using Microsoft.Xrm.Sdk;

namespace DES.Crm.Core.Common.XRM.SDK
{
    public partial class Library
    {
        private IOrganizationService service { get; set; }

        private Library() { }
        
        public Library(IOrganizationService Service)
        {
            this.service = Service;
        }
    }
}
