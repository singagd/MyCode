﻿using System;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;

namespace DES.Crm.Core.Common.XRM.SDK
{
    public partial class Library
    {
        /// <summary>
        /// Library methord is used to update the CRM entity record
        /// </summary>
        /// <param name="entity"></param>
        public void Update(Entity entity)
        {
            try
            {
                service.Update(entity);                
            }
            catch (Exception ex)
            {
                throw new Exception("Error while executing Update method" + ex.Message);
            }
            finally
            {

            }
        }

        /// <summary>
        /// Update Bulk Records
        /// </summary>
        /// <param name="objects"></param>
        /// <returns></returns>
        public ExecuteMultipleResponseItemCollection Update(EntityCollection objects)
        {
            ExecuteMultipleRequest requestWithResults;
            try
            {                
                requestWithResults = new ExecuteMultipleRequest()
                {
                    // Set the execution behavior to not continue after the first error is received
                    // and to not return responses.
                    Settings = new ExecuteMultipleSettings()
                    {
                        ContinueOnError = false,
                        ReturnResponses = true
                    },
                    Requests = new OrganizationRequestCollection()
                };

                // Update the entities that were previously created.
                EntityCollection update = objects;

                foreach (var entity in update.Entities)
                {
                    UpdateRequest updateRequest = new UpdateRequest { Target = entity };
                    requestWithResults.Requests.Add(updateRequest);
                }

                ExecuteMultipleResponse responseWithResults =
                    (ExecuteMultipleResponse)service.Execute(requestWithResults);

                return responseWithResults.Responses;                
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
            }            
        }
    }
}
