﻿using System;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Query;

namespace DES.Crm.Core.Common.XRM.SDK
{
    public partial class Library
    {       
        /// <summary>
        /// Method is used to execute Fetch XML Query
        /// </summary>
        /// <param name="FetchXML"></param>
        /// <returns></returns>
        public EntityCollection Execute(string FetchXML)
        {
            if (!String.IsNullOrEmpty(FetchXML))
            {
                var fetchExpression = new FetchExpression(FetchXML);

                try
                { 
                    var result = ((RetrieveMultipleResponse)service.Execute(new RetrieveMultipleRequest { Query = fetchExpression })).EntityCollection;
                    return result;
                }
                catch (Exception ex)
                {
                    throw new Exception("Error while executing ExecuteFetchXMLQuery" + ex.Message);
                }
                finally
                {

                }                
            }
            return null;
        }
    }
}
