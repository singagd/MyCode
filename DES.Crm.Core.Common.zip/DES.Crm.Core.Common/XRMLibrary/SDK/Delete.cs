﻿using Microsoft.Xrm.Sdk;
using System;

namespace DES.Crm.Core.Common.XRM.SDK
{
    public partial class Library
    {
        /// <summary>
        /// Library methord is used to delete the CRM entity record
        /// </summary>
        /// <param name="EntityName"></param>
        /// <param name="guid"></param>
        public void Delete(string EntityName, Guid guid)
        {
            try
            {
                service.Delete(EntityName, guid);             
            }
            catch (Exception ex)
            {
                throw new Exception("Error while executing Delete method" + ex.Message);
            }
            finally
            {

            }
        }
    }
}
