﻿using System;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;

namespace DES.Crm.Core.Common.XRM.SDK
{
    public partial class Library
    {
        /// <summary>
        /// Associate records
        /// </summary>
        /// <param name="EntityLogicalName"></param>
        /// <param name="SourceRecord"></param>
        /// <param name="relationship"></param>
        /// <param name="ReferenceRecords"></param>
        public void Associate(string EntityLogicalName, Guid SourceRecord, string relationship, EntityReferenceCollection ReferenceRecords)
        {
            try
            {
                Relationship relation = new Relationship(relationship);
                service.Associate(EntityLogicalName, SourceRecord, relation, ReferenceRecords);
            }
            catch (Exception ex)
            {
                throw new Exception("Error while Associate records" + ex.Message);
            }
            finally
            {

            }
        }

        /// <summary>
        /// Associate Requests in Bulk
        /// </summary>
        /// <param name="objects"></param>
        /// <param name="SourceEntity"></param>
        /// <param name="SourceAttribute"></param>
        /// <param name="DestinationEntity"></param>
        /// <param name="DestinationAttribute"></param>
        /// <param name="Relationship"></param>        
        /// <returns></returns>
        public ExecuteMultipleResponseItemCollection Associate(EntityCollection objects, string SourceEntity, string SourceAttribute, string DestinationEntity, string DestinationAttribute, string Relationship)
        {
            ExecuteMultipleRequest requestWithResults;

            try
            {                
                requestWithResults = new ExecuteMultipleRequest()
                {
                    // Assign settings that define execution behavior: continue on error, return responses. 
                    Settings = new ExecuteMultipleSettings()
                    {
                        ContinueOnError = false,
                        ReturnResponses = true
                    },                  
                    Requests = new OrganizationRequestCollection()
                };
                
                foreach (var entity in objects.Entities)
                {
                    if (entity != null)
                    {
                        var sourceMapId = ((Microsoft.Xrm.Sdk.EntityReference)entity.Attributes[SourceAttribute]).Id;
                        var destMapId = ((Microsoft.Xrm.Sdk.EntityReference)entity.Attributes[DestinationAttribute]).Id;

                        AssociateRequest associate = new AssociateRequest
                        {
                            Target = new EntityReference(DestinationEntity, destMapId),
                            RelatedEntities = new EntityReferenceCollection {
                                new EntityReference(SourceEntity, sourceMapId)
                            },
                            Relationship = new Relationship(Relationship)

                        };
                        requestWithResults.Requests.Add(associate);
                    }
                }

                // Execute all the requests in the request collection using a single web method call.
                ExecuteMultipleResponse responseWithResults =
                    (ExecuteMultipleResponse)service.Execute(requestWithResults);

                return responseWithResults.Responses;                
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {

            }
        }

        /// <summary>
        /// Disassociate records
        /// </summary>
        /// <param name="EntityLogicalName"></param>
        /// <param name="SourceRecord"></param>
        /// <param name="relationship"></param>
        /// <param name="ReferenceRecords"></param>
        public void Disassociate(string EntityLogicalName, Guid SourceRecord, string relationship, EntityReferenceCollection ReferenceRecords)
        {
            try
            {
                Relationship relation = new Relationship(relationship);
                service.Disassociate(EntityLogicalName, SourceRecord, relation, ReferenceRecords);
            }
            catch (Exception ex)
            {
                throw new Exception("Error while Disassociate records" + ex.Message);
            }
            finally
            {

            }
        }

        public void Assign(string SourceEntity, Guid SourceEntityRecord, string AssigneeEntityName, Guid AssigneeEntityReference)
        {
            try
            {
                AssignRequest assignRequest = new AssignRequest()
                {
                    Assignee = new EntityReference
                    {
                        LogicalName = AssigneeEntityName,
                        Id = AssigneeEntityReference
                    },

                    Target = new EntityReference(SourceEntity, SourceEntityRecord)
                };

                service.Execute(assignRequest);
            }
            catch (Exception ex)
            {
                throw new Exception("Error while record re-Assignments" + ex.Message);
            }
            finally
            {

            }
        }

        /// <summary>
        /// Set Status of records
        /// </summary>
        /// <param name="Reference"></param>
        /// <param name="State"></param>
        /// <param name="Status"></param>
        public void SetState(string EntityLogicalName, Guid RecordID, OptionSetValue State, OptionSetValue Status)
        {
            try
            {
                var setStateReq = new SetStateRequest
                {
                    EntityMoniker = new EntityReference(EntityLogicalName, RecordID),
                    State = State,
                    Status = Status
                };

                service.Execute(setStateReq);
            }
            catch (Exception ex)
            {
                throw new Exception("Error while Set Status in records" + ex.Message);
            }
            finally
            {

            }

        }        
    }
}
