﻿using System;
using DES.Crm.Core.Common.Security;
using Microsoft.Xrm.Sdk.Client;

namespace DES.Crm.Core.Common.XRM.Connections
{
    public class OrgnisationService
    {
        readonly string URL = null;        
        readonly string Name = null;
        readonly string Password = null;
        OrganizationServiceProxy OrgService = null;
        private OrgnisationService() { }
        public OrgnisationService(string OrgURL, string UserName, string EncryptedPassword)
        {
            URL = OrgURL;
            Name = UserName;
            Password = DataProtect.DecryptString(EncryptedPassword);
        }

        public OrganizationServiceProxy CreateOrgnisationService()
        {
            var orgURI = new Uri(URL);
            var credentials = new System.ServiceModel.Description.ClientCredentials();
            credentials.UserName.UserName = Name;
            credentials.UserName.Password = Password;

            try
            {
                if (OrgService != null)
                {
                    return OrgService;
                }
                else
                {
                    OrgService = new OrganizationServiceProxy(uri: orgURI, homeRealmUri: null, clientCredentials: credentials, deviceCredentials: null);
                    return OrgService;
                }
            }            
            catch (Exception ex)
            {
                throw new Exception("Connection Error: " + ex.Message);
            }
            finally
            {

            }
        }
    }
}
