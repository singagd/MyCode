﻿using System;
using System.Security;
using DES.Crm.Core.Common.Security;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Tooling.Connector;

namespace DES.Crm.Core.Common.XRM.Connections
{
    public class ServiceClient
    {
        CrmServiceClient Service = null;
        readonly string UserEmailId = null;
        readonly string CRMRegion = null;
        readonly string CRMOrgName = null;
        readonly SecureString UserNTPassword = null;

        private ServiceClient() { }

        public ServiceClient(string UserName, string EncryptedPassword, string Region, string OrgName)
        {
            UserEmailId = UserName;
            UserNTPassword = CrmServiceClient.MakeSecureString(DataProtect.DecryptString(EncryptedPassword));
            CRMRegion = Region;
            CRMOrgName = OrgName;            
        }

        public CrmServiceClient CreateSOAPConnection()
        {
            try
            {
                if (Service != null)
                {
                    return Service;
                }
                else
                {
                    //var connectionString = @"AuthType = Office365; Url = https://xxx.crm4.dynamics.com/;Username=xxx;Password=xxx";
                    //crmSvc = new CrmServiceClient(connectionString);

                    Service = new CrmServiceClient(crmUserId: UserEmailId, crmPassword: UserNTPassword, crmRegion: CRMRegion, orgName: CRMOrgName, isOffice365: true);                    
                    var whoAmI = (WhoAmIResponse)Service.Execute(new WhoAmIRequest());

                    return Service;
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Connection Error: " + ex.Message);
            }
            finally
            {

            }
        }

    }
}
