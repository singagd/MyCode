﻿using System;
using System.Activities;
using System.Globalization;
using System.ServiceModel;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Workflow;

namespace DES.Crm.Core.Common.XRM.SDK
{
    public abstract class WorkFlowActivityBase : CodeActivity
    {
        private ICRMObjects crmObjects;
        protected string ChildClassName { get; private set; }
        public WorkFlowActivityBase() { }
        private ICRMObjects CreateInitialObjects(CodeActivityContext executionContext)
        {
            if (executionContext == null)           
                throw new ArgumentNullException("Workflow CodeActivityContext not found!!");

            crmObjects = new CRMObjects();

            crmObjects.executionContext = executionContext;

            crmObjects.WorkflowExecutionContext = (IWorkflowContext)executionContext.GetExtension<IWorkflowContext>();
            crmObjects.TracingService = (ITracingService)executionContext.GetExtension<ITracingService>();

            crmObjects.factory = (IOrganizationServiceFactory)executionContext.GetExtension<IOrganizationServiceFactory>();            
            crmObjects.Service = crmObjects.factory.CreateOrganizationService(crmObjects.WorkflowExecutionContext.UserId);

            return crmObjects;

        }
        public void Trace(string message)
        {
            if (string.IsNullOrWhiteSpace(message) || crmObjects.TracingService == null)
            {
                return; 
            }

            if (crmObjects.WorkflowExecutionContext == null)
            {
                crmObjects.TracingService.Trace(message);
            }
            else
            {
                crmObjects.TracingService.Trace(
                    "{0}, Correlation Id: {1}, Initiating User: {2}",
                    message,
                    crmObjects.WorkflowExecutionContext.CorrelationId,
                    crmObjects.WorkflowExecutionContext.InitiatingUserId);
            }
        }       

        public WorkFlowActivityBase(Type childClassName)
        {
            this.ChildClassName = childClassName.ToString();
        }

        protected override void Execute(CodeActivityContext executionContext)
        {
            if (executionContext == null)
                throw new ArgumentNullException("Workflow CodeActivityContext not found!!");

            Trace(string.Format(CultureInfo.InvariantCulture, "Entered {0}.Execute()", this.ChildClassName));

            try
            {
                if (crmObjects == null)
                    crmObjects = CreateInitialObjects(executionContext);
                
                this.ExecuteWorkflow(crmObjects);

                return;
            }
            catch (FaultException<OrganizationServiceFault> e)
            {
                Trace(string.Format(CultureInfo.InvariantCulture, "Exception: {0}", e.ToString()));

                // Handle the exception.
                throw;
            }
            finally
            {
                Trace(string.Format(CultureInfo.InvariantCulture, "Exiting {0}.Execute()", this.ChildClassName));
            }
        }

        protected abstract void ExecuteWorkflow(ICRMObjects crmObjects);
    }
}
