﻿using System;
using System.Globalization;
using System.ServiceModel;
using Microsoft.Xrm.Sdk;

namespace DES.Crm.Core.Common.XRM.SDK
{
    public abstract class PluginBase : IPlugin
    {
        private ICRMObjects crmObjects;
        protected string ChildClassName { get; private set; }
        public PluginBase() { }
        private ICRMObjects CreateInitialObjects(IServiceProvider serviceProvider)
        {
            if (serviceProvider == null)
                throw new ArgumentNullException("ServiceProvider is null");

            crmObjects = new CRMObjects();       

            crmObjects.ServiceProvider = serviceProvider;

            crmObjects.PluginExecutionContext = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
            crmObjects.TracingService = (ITracingService)serviceProvider.GetService(typeof(ITracingService));

            crmObjects.factory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            crmObjects.Service = crmObjects.factory.CreateOrganizationService(crmObjects.PluginExecutionContext.UserId);

            return crmObjects;
        }
        protected internal void Trace(string message)
        {
            if (string.IsNullOrWhiteSpace(message) || crmObjects.TracingService == null)
            {
                return;
            }

            if (crmObjects.PluginExecutionContext == null)
            {
                crmObjects.TracingService.Trace(message);
            }
            else
            {
                crmObjects.TracingService.Trace("{0}, Correlation Id: {1}, Initiating User: {2}", message, crmObjects.PluginExecutionContext.CorrelationId, crmObjects.PluginExecutionContext.InitiatingUserId);
            }
        }                

        protected internal PluginBase(Type childClassName)
        {
            this.ChildClassName = childClassName.ToString();
        }        

        public void Execute(IServiceProvider serviceProvider)
        {
           if(serviceProvider == null)           
                throw new ArgumentNullException("Service not found!!");
            
                       
            Trace(string.Format(CultureInfo.InvariantCulture, "Entered {0}.Execute()", this.ChildClassName));

            try
            {
                if (crmObjects == null)
                    crmObjects = CreateInitialObjects(serviceProvider);
                
                this.ExecutePlugin(crmObjects);

                return;               
            }
            catch (FaultException<OrganizationServiceFault> e)
            {
                Trace(string.Format(CultureInfo.InvariantCulture, "Exception: {0}", e.ToString()));

                // Handle the exception.
                throw;
            }
            finally
            {
                Trace(string.Format(CultureInfo.InvariantCulture, "Exiting {0}.Execute()", this.ChildClassName));
            }
        }

        protected abstract void ExecutePlugin(ICRMObjects crmObjects);
    }    
}
