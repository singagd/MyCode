﻿using System;
using System.Activities;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Workflow;

namespace DES.Crm.Core.Common.XRM.SDK
{
    public class CRMObjects : ICRMObjects
    {
        public IServiceProvider ServiceProvider { get; set; }
        public IPluginExecutionContext PluginExecutionContext { get; set; }
        public ITracingService TracingService { get; set; }
        public IOrganizationServiceFactory factory { get; set; }
        public IOrganizationService Service { get; set; }
        public IWorkflowContext WorkflowExecutionContext { get; set; }
        public CodeActivityContext executionContext { get; set; }  
        
        public CRMObjects() { }
        public string ChildClassName { get; set; }

    }
}


